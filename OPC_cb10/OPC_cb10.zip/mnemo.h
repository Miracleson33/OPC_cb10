//---------------------------------------------------------------------------

#ifndef mnemoH
#define mnemoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <ComCtrls.hpp>

//---------------------------------------------------------------------------
class TMnemo
{
	public:
	AnsiString Name;
	AnsiString About;
	AnsiString Img;
	int NTable[100];
	AnsiString NameTag[100];
	AnsiString AboutTag[100];
	int X[100];
	int Y[100];
	bool UseTag[100];
	int NumTags;
};
//---------------------------------------------------------------------------
//-------------------------------------------------------
//---------------------------------------------------------------------------
class TTOU
{
public:
	TLabel *LabelTOU;
	TImage *Image1TOU;
	TImage *Image2TOU;
	__fastcall TTOU(int id, int x, int y);
	__fastcall ~TTOU(void);
	void __fastcall POnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	void __fastcall POnMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	void __fastcall POnMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void SetPosTOU(int x0, int y0, int x, int y);
	int idTOU;
	bool UseTOU;
	AnsiString NameTOU;
	AnsiString AboutTOU;
	AnsiString ImageFileTOU;
	int TypeTOU;
	int X;
	int Y;
	int ControlParam;
};
//---------------------------------------------------------------------------
//-------------------------------------------------------
//---------------------------------------------------------------------------
class TTag : public TLabel
{
public:
	__fastcall TTag(int id, int x, int y);
	__fastcall ~TTag(void);
	void __fastcall POnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	void __fastcall POnMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	void __fastcall POnMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
//	void POnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
//	void POnMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
//	void POnMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
//	void __fastcall SetPosTag(int x0, int y0, int x, int y);
//	void SetPosTag(int x0, int y0, int x, int y);
	int idTag;
	bool UseTag;
	int NTable;
	int NParam;
	AnsiString NameTag;
	AnsiString AboutTag;
	double Val;
	int X;
	int Y;
};
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//-------------------------------------------------------
//-------------------------------------------------------
//-------------------------------------------------------
class TMnemoForm : public TForm
{
__published:	// IDE-managed Components
	TGroupBox *MnemoBox;
	TImage *MnemoField;
	TGroupBox *ControlBox;
	TGroupBox *EditBox;
	TStringGrid *ServersGrid;
	TButton *ButtonClose;
	TButton *ButtonEdit;
	TStringGrid *TagsGrid;
	TLabel *Label1;
	TTimer *TagsLoop;
	TStringGrid *AddedTagsGrid;
	TButton *AddTagButton;
	TButton *DeleteTagButton;
	TEdit *XTagEdit;
	TEdit *YTagEdit;
	TLabel *NameTagLabel;
	TLabel *AboutTagLabel;
	TLabel *LabelNameTagLabel;
	TLabel *LabelAboutTagLabel;
	TLabel *LabelXTagLabel;
	TLabel *LabelYTagLabel;
	TCheckBox *GoEdit;
	TCheckBox *NowTimeBox;
	TDateTimePicker *DateTimePicker1;
	TDateTimePicker *DateTimePicker2;
	TLabel *TimeLabel;
	void __fastcall ButtonCloseClick(TObject *Sender);
	void __fastcall ButtonEditClick(TObject *Sender);
	void __fastcall ServersGridDrawCell(TObject *Sender, int ACol, int ARow, TRect &Rect,
          TGridDrawState State);
	void __fastcall ServersGridSelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);
	void __fastcall TagsGridDrawCell(TObject *Sender, int ACol, int ARow, TRect &Rect,
          TGridDrawState State);
	void __fastcall TagsGridSelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);
	void __fastcall TagsGridDragDrop(TObject *Sender, TObject *Source, int X, int Y);
	void __fastcall TagsGridDragOver(TObject *Sender, TObject *Source, int X, int Y,
          TDragState State, bool &Accept);
	void __fastcall TagsGridEndDock(TObject *Sender, TObject *Target, int X, int Y);
	void __fastcall TagsGridEndDrag(TObject *Sender, TObject *Target, int X, int Y);
	void __fastcall MnemoFieldMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall TagsLoopTimer(TObject *Sender);
	void __fastcall MnemoFieldMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall MnemoFieldMouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall AddTagButtonClick(TObject *Sender);
	void __fastcall DeleteTagButtonClick(TObject *Sender);
	void __fastcall FormKeyPress(TObject *Sender, wchar_t &Key);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall GoEditClick(TObject *Sender);
	void __fastcall AddedTagsGridDrawCell(TObject *Sender, int ACol, int ARow, TRect &Rect,
          TGridDrawState State);
	void __fastcall AddedTagsGridSelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);









private:	// User declarations
public:		// User declarations
//	void __fastcall DLabelOnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y);
	__fastcall TMnemoForm(TComponent* Owner);
//	void __fastcall SetMnemo(bool EditMode);
//	void __fastcall LoadMnemoConfig();
//	void __fastcall ListServers();
//	void __fastcall ListTags(int id);
//	void __fastcall RefreshTags(int idTag);
	void SetMnemo(bool EditMode);
	void LoadMnemoConfig();
	void SaveMnemoConfig();
	void ListServers();
	void ListTags(int id);
	void RefreshTOU(int idTOU);
	void RefreshTags(int idTag);
	void InitTags();
	void Init(AnsiString AboutMnemo);
	void SetPosTOU(int id, int x, int y, bool Manual);
	void SetPosTag(int id, int x, int y, bool Manual);
	void ListAddedTags();


	TTag *LTags[100];
	int MaxTags;
	int NumTags;

	TTOU *TOU[100];
	int MaxTOU;
	int NumTOU;

	int X0Mnemo;
	int Y0Mnemo;
	TMnemo M[10];
	int MaxMnemo;
	int NumMnemo;
	int CurMnemo;
	AnsiString VerConfigMnemo;

	int SelectedRowServer;
	int SelectedRowTag;
	bool EditMode;
	bool AddTagMode;
//protected:
	int SelectedTag;
	int SelectedTOU;
	bool MDown;
};
//---------------------------------------------------------------------------
//extern PACKAGE TTag *LTags[100];
extern PACKAGE TMnemoForm *MnemoForm;
//---------------------------------------------------------------------------
#endif
