//---------------------------------------------------------------------------

#ifndef selectcolorH
#define selectcolorH
#include <main.h>
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TSelectColorForm : public TForm
{
__published:	// IDE-managed Components
    TStringGrid *StringGrid1;
	TEdit *Edit1;
	TLabel *Label10;
	TEdit *Edit2;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TButton *Button1;
	TButton *Button2;
	TEdit *Edit3;
	TLabel *Label4;
	TEdit *Edit4;
	TLabel *Label5;
	TLabel *Label6;
	TCheckBox *CheckBox1;
    void __fastcall StringGrid1SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
    void __fastcall StringGrid1DrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall CheckBox1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TSelectColorForm(TComponent* Owner);
	int SelectedRow;
};
//---------------------------------------------------------------------------
extern PACKAGE TSelectColorForm *SelectColorForm;
//---------------------------------------------------------------------------
#endif
