//---------------------------------------------------------------------------

#ifndef trendsH
#define trendsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//#include "PERFGRAP.h"
//---------------------------------------------------------------------------
#include <main.h>
#include <LoadTrendsThread.h>
#include <ExtCtrls.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
#include <Grids.hpp>
#include <CheckLst.hpp>
#include <ComCtrls.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------

class TViewTrends
{
public:		// User declarations
    //int Color;
	TPoint Points[4000];
	int IntCursorVal;
	float FloatCursorVal;
	bool BoolCursorVal;
//��� ���� 0-float 1-int 2-bool
	int TypeVal;
	float YRatio;
};

class TPointsTrends
{
public:		// User declarations
	float Y[100000];
	int IntCurrentVal;
    float FloatCurrentVal;
    bool BoolCurrentVal;
	int IntCursorVal;
	float FloatCursorVal;
	bool BoolCursorVal;
//��� ���� 0-float 1-int 2-bool
    int TypeVal;
};
class TTrendForm : public TForm
{
__published:	// IDE-managed Components
    TImage *Image1;
    TGroupBox *GroupBox1;
    TButton *Button2;
    TRadioButton *RadioButton1;
    TRadioButton *RadioButton2;
    TStringGrid *StringGrid1;
    TProgressBar *ProgressBar1;
    TADOQuery *TrendsDS_Thread;
	TImage *Image2;
	TImage *Image3;
	TImage *Image4;
	TBitBtn *BitBtn1;
	TBitBtn *BitBtn2;
	TBitBtn *BitBtn3;
	TBitBtn *BitBtn4;
	TBitBtn *BitBtn5;
	TBitBtn *BitBtn6;
	TBitBtn *BitBtn7;
	TBitBtn *BitBtn8;
	TBitBtn *BitBtn9;
	TBitBtn *BitBtn10;
	TBitBtn *BitBtn11;
	TBitBtn *BitBtn12;
	TBitBtn *BitBtn13;
	TBitBtn *BitBtn14;
	TLabel *Label9;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TADOQuery *TrendsDS_Cursor;
	TADOConnection *ADOConnection1;
	TADOQuery *TablesDS;
	TLabel *Label7;
	TLabel *Label6;
	TImage *Image5;
	TCheckBox *CheckBox1;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall RadioButton1Click(TObject *Sender);
    void __fastcall RadioButton2Click(TObject *Sender);
    void __fastcall StringGrid1DrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
    void __fastcall StringGrid1SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
    void __fastcall Button5Click(TObject *Sender);
    void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall BitBtn1Click(TObject *Sender);
	void __fastcall BitBtn2Click(TObject *Sender);
	void __fastcall BitBtn3Click(TObject *Sender);
	void __fastcall BitBtn4Click(TObject *Sender);
	void __fastcall BitBtn5Click(TObject *Sender);
	void __fastcall BitBtn6Click(TObject *Sender);
	void __fastcall BitBtn7Click(TObject *Sender);
	void __fastcall BitBtn8Click(TObject *Sender);
	void __fastcall BitBtn10Click(TObject *Sender);
	void __fastcall BitBtn9Click(TObject *Sender);
	void __fastcall BitBtn13Click(TObject *Sender);
	void __fastcall BitBtn14Click(TObject *Sender);
	void __fastcall BitBtn12Click(TObject *Sender);
	void __fastcall BitBtn11Click(TObject *Sender);
	void __fastcall Image5MouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift,
          int X, int Y);
	void __fastcall Image5MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall CheckBox1Click(TObject *Sender);


private:	// User declarations
public:		// User declarations
    __fastcall TTrendForm(TComponent* Owner);
    void SetViewMode(bool Mode);
    void SetView();
    void LoadTrends(bool LoadDBData);
	void ShowTrends(bool LoadDBData);
	void ConnectDB(String pth);

    TDateTime TrendsDateTime[100000];
	TDateTime ViewTrendsDateTime[4000];
	int nRecords [100000];
	int nViewRecords [4000];
	int nTables [100000];
	int nViewTables [4000];
	int Cursor;

    bool TrendsListGenerate;
    bool StopLoadTrendsThread;
	bool ViewMode;
	bool ShowValuesTrends;
    int MaxX;
	int MaxY;
//	float DY;
//    int MidY;

    int ScaleX;
    int ScaleY;
    long int NumRecordStart;

	TViewTrends ViewTrends[128];
	TPointsTrends PointsTrends[128];
    int MaxTrends;
    int MaxTrendPoints;
    int MaxViewTrendPoints;
    int SelectedParam;
    long int NumTrendRecords;
    long int NumTrendPoints;
	long int NumViewTrendPoints;
	int nTable;

	TADOQuery* ParamsDS;
	TADOQuery* ValuesDS;
	TADOQuery* ValuesDS_Cursor;
	TADOConnection* DBSQLConn;

};
//---------------------------------------------------------------------------
extern PACKAGE TTrendForm *TrendForm;
//---------------------------------------------------------------------------
#endif
