//---------------------------------------------------------------------------

#ifndef findservH
#define findservH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
//---------------------------------------------------------------------------
#include <FindServersThread.h>
//---------------------------------------------------------------------------
class TForm2 : public TForm
{
__published:	// IDE-managed Components
    TLabel *Label1;
    TProgressBar *ProgressBar1;
    TButton *Button1;
    void __fastcall FormActivate(TObject *Sender);
    void __fastcall Button1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
    __fastcall TForm2(TComponent* Owner);


    void __fastcall GetServers();
//    bool FindServersStat;
    int __fastcall FindServers(int Version);
    bool AbortFindServers;
//    TFindServersTread *ThrFindServ;
    AnsiString ComputerName;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm2 *Form2;
//---------------------------------------------------------------------------
#endif
