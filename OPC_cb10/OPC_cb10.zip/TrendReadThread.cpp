//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TrendReadThread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(&UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TTrendReadThread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
#include <main.h>
//---------------------------------------------------------------------------
inline AnsiString Variant2Str(VARIANT& v)
{
    Variant var(v);
    return VarToStr(var);
}

//---------------------------------------------------------------------------

__fastcall TTrendReadThread::TTrendReadThread(bool CreateSuspended)
	: TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
__fastcall TTrendReadThread::~TTrendReadThread(void)
{
	Form1->ThrTrendsRead=NULL;
	Form1->CloseTrendsReadThread=false;
}
//---------------------------------------------------------------------------

void __fastcall TTrendReadThread::Execute()
{
	FreeOnTerminate=true;
	Priority = tpLower; //tpIdle; //tpNormal;
	while (!Form1->CloseTrendsReadThread)
	{
		Form1->LastTimeTrendsReadThread = Now();
		if (Form1->Time1s1)
		{
			Form1->NumReads=0;
			for (int j=0;j<Form1->NumConnectedOPCServers;j++)
			{
				if (
//				true
				((
					Form1->OPCServers[j].ServerConnect &
					Form1->OPCServers[j].nItems>0) &
					Form1->OPCServers[j].GroupAdd &
					Form1->OPCServers[j].SyncRead )
				)
				{
					ServerRead=j;
					phResultRead = NULL;
					ULONG nItems=Form1->OPCServers[j].nItems;
					if (nItems>Form1->MaxParams) nItems=Form1->MaxParams;
					ULONG i=0;
					for (i=0;i<nItems;i++)
					{
						ItemRead=i;
						if ((j==0)&(i==(nItems-1)))
						{
							Form1->OPCServers[j].FloatValField[i] = Form1->DifTimeTrendsReadThread1;
							ShowRow=i;
							ShowVal=Form1->DifTimeTrendsReadThread1;
							Synchronize(Show);
						}
						else
						{
						Synchronize(Read);
						if (SUCCEEDED(hrRead)) //(true)//
						{
							if (SUCCEEDED(phResultRead[0])) //(true)//
							{
								if (Form1->TTrends[j].TypeField[i]==0)
								{
									Form1->OPCServers[j].FloatValField[i] = pItemStateRead[0].vDataValue.fltVal;
//									Form1->TTrends[j].FloatValField[i] = pItemStateRead[0].vDataValue.fltVal;
								}
								if (Form1->TTrends[j].TypeField[i]==1)
								{
									Form1->OPCServers[j].IntValField[i] = pItemStateRead[0].vDataValue.intVal;
//									Form1->TTrends[j].IntValField[i] = pItemStateRead[0].vDataValue.intVal;
								}
								if (Form1->TTrends[j].TypeField[i]==2)
								{
									Form1->OPCServers[j].BoolValField[i] = pItemStateRead[0].vDataValue.boolVal;
//									Form1->TTrends[j].BoolValField[i] = pItemStateRead[0].vDataValue.boolVal;
								}

								if ((Form1->ShowValues)&&(Form1->SelectedOPCServer==j))
								{
									ShowRow=i;
									ShowVal=Variant2Str(pItemStateRead[0].vDataValue);
									Synchronize(Show);
									ShowNum=nItems;
								}
								Form1->m_ptrMalloc->Free(pItemStateRead);
								Form1->m_ptrMalloc->Free(phResultRead);
							}
							else
							{
								Form1->m_ptrMalloc->Free(phResultRead);
								Form1->m_ptrMalloc->Free(pItemStateRead);
							}
							Form1->NumReads++;
						}
						else
						{

//							Application->MessageBox(L"���� ������", L"���������", MB_OK);
							Form1->NumErrorsReads++;
						}
						}
					}
				}
			}
			Synchronize(ShowInfo);
		}

		if (Form1->Time5s1)
		{
			Form1->Time5s1=false;
			if (Form1->TrendsStoreRemoute) Form1->TrendsStoredRemoute=false;
			if (Form1->TrendsStoreLocal) Form1->TrendsStoredLocal=false;
			double CurrentTime = (double)Form1->CurrentTime;
			if (CurrentTime>Form1->TimeReOpen)
			{
				if (Form1->TrendsStoreLocal)
				{
					for (int j=0;j<Form1->NumConnectedOPCServers;j++)
					{
						if (Form1->OPCServers[j].ServerConnect)
						{
							nTrendFile=Form1->OPCServers[j].idTrend;
							Synchronize(ReOpenDB);
						}
					}
				}
				Form1->TimeReOpen=Form1->TimeReOpen+Form1->NumDayTrendFile;
			}
//			else
//			{
//				Form1->ReOpened=false;
//			}
		}

		if (Form1->TrendsStoreRemoute)
		{
			Form1->NumSaves=0;
			if (!Form1->TrendsStoredRemoute)
			{
				for (int j=0;j<Form1->NumConnectedOPCServers;j++)
				{
					if (Form1->OPCServers[j].ServerConnect)
					{
						ULONG nItems=Form1->OPCServers[j].nItems;
						if (nItems>Form1->MaxParams) nItems=Form1->MaxParams;
						for (int k=j;k<Form1->NumConnectedOPCServers;k++)
						{
							int idTrend=Form1->OPCServers[j].idTrend;
							if (!Form1->ValidOPCServers[k].CLSID.AnsiCompare(Form1->OPCServers[idTrend].CLSIDOPCServer.m_str) &&
								!Form1->ValidOPCServers[k].ComputerName.AnsiCompare(Form1->OPCServers[idTrend].ComputerName)    )
							{

								if ((idTrend>=0)&&(idTrend<Form1->NumBD))
								{
									if (!Form1->DBSQLConn[idTrend]->Connected)
									{
										Form1->ConnectDBSQL(idTrend);
										Form1->MaxDifTimeTrendsReadThread=0;
									}
									AnsiString QueryTrend = "select * from "+Form1->TableVals[idTrend];
//									QueryTrend.operator +=(Form1->ListTrends[idTrend].TableName);
//									QueryTrend.operator +=(Form1->ListTrends[idTrend].TableNamePrefix[0]);
									Form1->ValuesDS[idTrend]->SQL->Clear();
									Form1->ValuesDS[idTrend]->SQL->Add(QueryTrend);
									try {
										Form1->ValuesDS[idTrend]->Open();
									} catch (...) {
									 //	Form1->ValuesDS[idTrend]->
									 int g=6;
									}
									if (Form1->ValuesDS[idTrend]->RecordCount>Form1->RecordsInTable)
									{
										iidTrend=idTrend;
										Synchronize(ReconnectDBSQL);
									}
									ULONG i=0;
									if (j==3)
									{
										int ui=1;
									}
									for (i=0;i<nItems;i++)
									{
										if (j==3)
										{
											int ui=1;
										}
										AnsiString FieldDB=Form1->OPCServers[idTrend].NameDBItem[i];
										Form1->ValuesDS[idTrend]->Insert();
										Form1->ValuesDS[idTrend]->FieldByName("date")->AsDateTime = Now();
										Form1->ValuesDS[idTrend]->FieldByName("param")->AsInteger=i;
										if (Form1->TTrends[idTrend].TypeField[i]==0)
										{
//Form1->ValuesDS[idTrend]->InsertRecord(
//ARRAYOFCONST((i, Now(), i, Form1->OPCServers[idTrend].FloatValField[i])));
											Form1->ValuesDS[idTrend]->FieldByName("val")->AsFloat = Form1->OPCServers[idTrend].FloatValField[i];
										}
										if (Form1->TTrends[idTrend].TypeField[i]==1)
										{
											Form1->ValuesDS[idTrend]->FieldByName("val")->AsFloat  = (float)Form1->OPCServers[idTrend].IntValField[i];
										}
										if (Form1->TTrends[idTrend].TypeField[i]==2)
										{
											Form1->ValuesDS[idTrend]->FieldByName("val")->AsFloat  = (float)Form1->OPCServers[idTrend].BoolValField[i];
										}
										Form1->NumSaves++;
										if (j==3)
										{
											int ui=1;
										}
									}
									if (j==3)
									{
										int ui=1;
									}
									Form1->ValuesDS[idTrend]->Post();
									if (j==3)
									{
										int ui=1;
									}
									Form1->TablesDS[idTrend]->SQL->Clear();
									wchar_t idTablesS[5];
									_itow (Form1->idTables[idTrend], idTablesS, 10);
									AnsiString QueryTrend1 = "select * from tables where id=";
									QueryTrend1+=idTablesS;
									Form1->TablesDS[idTrend]->SQL->Add(QueryTrend1);
//									Form1->TablesDS[idTrend]->ExecSQL();
									Form1->TablesDS[idTrend]->Open();
									Form1->TablesDS[idTrend]->Edit();
									Form1->TablesDS[idTrend]->FieldByName("reccount")->AsInteger=Form1->ValuesDS[idTrend]->RecordCount;
									Form1->TablesDS[idTrend]->FieldByName("endtime")->AsDateTime=Now();
									Form1->TablesDS[idTrend]->Post();
//									Form1->TablesDS[idTrend]->Close();
//									Form1->ValuesDS[idTrend]->Close();
								}
							}
						}
					}
				}

				Form1->NumStoredRemoute++;
				Form1->TrendsStoredRemoute=true;
				Form1->Time5s1=false;
				Synchronize(ShowInfo);
			}
		}
		else
		{
			for (int k=0;k<Form1->NumConnectedOPCServers;k++)
			{
				int idTrend=Form1->OPCServers[k].idTrend;
				if (Form1->DBSQLConn[idTrend]->Connected)
				{
					Form1->ValuesDS[idTrend]->Close();
					Form1->ParamsDS[idTrend]->Close();
					Form1->TablesDS[idTrend]->Close();
					Form1->DBSQLConn[idTrend]->Close();
				}
			}

		}

		if (Form1->TrendsStoreLocal)
		{
			Form1->NumSaves=0;;
			if (!Form1->TrendsStoredLocal)
			{
				for (int j=0;j<Form1->NumConnectedOPCServers;j++)
				{
					if (Form1->OPCServers[j].ServerConnect)
					{
						ULONG nItems=Form1->OPCServers[j].nItems;
						if (nItems>Form1->MaxParams) nItems=Form1->MaxParams;
						for (int k=j;k<Form1->NumConnectedOPCServers;k++)
						{
							if (!Form1->ValidOPCServers[k].CLSID.AnsiCompare(Form1->OPCServers[j].CLSIDOPCServer.m_str) &&
								!Form1->ValidOPCServers[k].ComputerName.AnsiCompare(Form1->OPCServers[j].ComputerName)    )
							{
								int nTable=-1, nTr=0;
								int idTrend=Form1->OPCServers[j].idTrend;

								Form1->TablesDS[Form1->OPCServers[j].idTrend]->Open();
								Form1->TablesDS[Form1->OPCServers[j].idTrend]->First();

								AnsiString RecordCountFieldTables = "recordcount";

								while ((!Form1->TablesDS[idTrend]->Eof)&&(nTable==-1))
								{
									int nr=Form1->TablesDS[idTrend]->FieldByName(RecordCountFieldTables)->AsInteger;
									if (nr<Form1->RecordsInTable)
									{
										nTable = nTr;
									}
									else
									{
										Form1->TablesDS[idTrend]->Next();
									}
									nTr++;
								}

								if (nTable==-1)
								{
									nTrendFile=Form1->OPCServers[j].idTrend;
									Synchronize(ReOpenDB);
									nTable=0;
								}

								AnsiString QueryTrend = "select * from ";
								QueryTrend.operator +=(Form1->ListTrends[j].TableName);
								QueryTrend.operator +=(Form1->ListTrends[j].TableNamePrefix[nTable]);
								Form1->TrendsDS[idTrend]->SQL->Clear();
								Form1->TrendsDS[idTrend]->SQL->Add(QueryTrend);
								Form1->TrendsDS[idTrend]->Open();
								Form1->TrendsDS[idTrend]->Insert();
								Form1->TrendsDS[idTrend]->FieldByName(Form1->TTrends[j].DateField)->AsDateTime = Now();
								for (ULONG i=0;i<nItems;i++)
								{
									AnsiString FieldDB=Form1->OPCServers[j].NameDBItem[i];
									if (Form1->TTrends[j].TypeField[i]==0)
									{
										Form1->TrendsDS[idTrend]->FieldByName(FieldDB)->AsFloat = Form1->OPCServers[j].FloatValField[i];
									}
									if (Form1->TTrends[j].TypeField[i]==1)
									{
										Form1->TrendsDS[idTrend]->FieldByName(FieldDB)->AsFloat  = (float)Form1->OPCServers[j].IntValField[i];
									}
									if (Form1->TTrends[j].TypeField[i]==2)
									{
										Form1->TrendsDS[idTrend]->FieldByName(FieldDB)->AsFloat  = (float)Form1->OPCServers[j].BoolValField[i];
									}
									Form1->NumSaves++;
								}
								Form1->TrendsDS[idTrend]->Post();
								Form1->TablesDS[idTrend]->Edit();
								Form1->TablesDS[idTrend]->FieldByName(RecordCountFieldTables)->AsInteger=Form1->TrendsDS[idTrend]->RecordCount;
								Form1->TablesDS[idTrend]->Post();

								Form1->TablesDS[idTrend]->Close();
								Form1->TrendsDS[idTrend]->Close();
							}
						}
					}
				}

				Form1->NumStoredLocal++;
				Form1->TrendsStoredLocal=true;
				Form1->Time5s1=false;
				Synchronize(ShowInfo);
			}
		}

	}
}
//---------------------------------------------------------------------------

void __fastcall TTrendReadThread::Read()
{
	hrRead = Form1->OPCServers[ServerRead].OPCSyncIO->Read(OPC_DS_DEVICE, 1, &Form1->OPCServers[ServerRead].hOPCItem[ItemRead], &pItemStateRead, &phResultRead);
}
//---------------------------------------------------------------------------

void __fastcall TTrendReadThread::ReOpenDB()
{
	Form1->ReOpenDB(nTrendFile, true);
}
//---------------------------------------------------------------------------
void __fastcall TTrendReadThread::ReconnectDBSQL()
{
	Form1->ReconnectDBSQL(iidTrend);
}
//---------------------------------------------------------------------------
void __fastcall TTrendReadThread::Show()
{
	int len=5;
	if (len>ShowVal.Length()) len=ShowVal.Length();
	Form1->StringGrid2->Cells[2][ShowRow]=ShowVal.SetLength(len) ;
}
//---------------------------------------------------------------------------

void __fastcall TTrendReadThread::ShowInfo()
{
	wchar_t s[8];

	AnsiString sca = "����������: ";
	_itow(ShowNum, s, 10);
	sca.operator +=(s);
	Form1->Label2->Caption=sca;

	Form1->Time1s1=false;
	AnsiString res = "��������: ";

	_itow(Form1->NumReads, s, 10);
	res.operator +=(s);
	Form1->Label14->Caption=res;

	AnsiString sav = "���������: ";
	_itow(Form1->NumSaves, s, 10);
	sav.operator +=(s);
	Form1->Label8->Caption=sav;

	AnsiString ers = "������: ";
	_itow(Form1->NumErrorsReads, s, 10);
	ers.operator +=(s);
	Form1->Label15->Caption=ers;
}
//---------------------------------------------------------------------------
