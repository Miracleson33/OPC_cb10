//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LoadTrendsThread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TLoadTrendsThread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall TLoadTrendsThread::TLoadTrendsThread(bool CreateSuspended)
    : TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void __fastcall TLoadTrendsThread::Execute()
{
	Priority = tpLower; //tpIdle; //tpNormal;
    float FloatVal=-2;
    int IntVal=-1;
	bool BoolVal=false;
	float y;
	int j;
	if (Form1->ViewRemouteTrends)
	{
		try
		{
			while ((TrendForm->MaxTrendPoints>TrendForm->NumTrendPoints)&&(!TrendForm->ValuesDS->Bof)&&(!TrendForm->StopLoadTrendsThread))
			{

            }
		} catch (...)
		{
		}
	}
	else
	{
		AnsiString IdField=Form1->TTrends[Form1->SelectedTrend].IdField;
		AnsiString DateField=Form1->TTrends[Form1->SelectedTrend].DateField;
		while ((TrendForm->MaxTrendPoints>TrendForm->NumTrendPoints)&&(!TrendForm->TrendsDS_Thread->Bof)&&(!TrendForm->StopLoadTrendsThread))
		{
			TrendForm->TrendsDateTime[TrendForm->NumTrendPoints]=TrendForm->TrendsDS_Thread->FieldByName(DateField)->AsDateTime;
			TrendForm->nRecords[TrendForm->NumTrendPoints]=TrendForm->TrendsDS_Thread->FieldByName(IdField)->AsInteger;
			TrendForm->nTables[TrendForm->NumTrendPoints]=TrendForm->nTable;
			for (j=0;j<TrendForm->MaxTrends;j++)//1;j++)//
			{
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j]==0)
				{
					FloatVal=TrendForm->TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					y = FloatVal;
				}
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j]==1)
				{
					IntVal=(int)TrendForm->TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					y = IntVal;
				}
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j]==2)
				{
					BoolVal=(bool)TrendForm->TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					if (BoolVal)
						y = 250;
					else
						y = 50;
				}
				TrendForm->PointsTrends[j].Y[TrendForm->NumTrendPoints] = y;
			}
			TrendForm->TrendsDS_Thread->Prior();
			if (TrendForm->TrendsDS_Thread->Bof)
			{
				if (TrendForm->nTable>0)
				{
					TrendForm->nTable--;
					AnsiString QueryTrend = "select * from ";
					QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
					QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[TrendForm->nTable]);
					QueryTrend.operator +=(" order by id asc");
					TrendForm->TrendsDS_Thread->SQL->Clear();
					TrendForm->TrendsDS_Thread->SQL->Add(QueryTrend);
					TrendForm->TrendsDS_Thread->Open();
					TrendForm->NumTrendRecords += TrendForm->TrendsDS_Thread->RecordCount;
					TrendForm->TrendsDS_Thread->Last();
				}
			}
			TrendForm->NumTrendPoints++;
		}
		TrendForm->TrendsDS_Thread->Close();
	}
}
//---------------------------------------------------------------------------

