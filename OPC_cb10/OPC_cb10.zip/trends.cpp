// ---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "trends.h"
// ---------------------------------------------------------------------------
#pragma package(smart_init)
// #pragma link "PERFGRAP"
#pragma resource "*.dfm"
TTrendForm *TrendForm;

// ---------------------------------------------------------------------------
__fastcall TTrendForm::TTrendForm(TComponent* Owner) : TForm(Owner)
{
	ValuesDS = new TADOQuery(this);
	ValuesDS_Cursor = new TADOQuery(this);
	ParamsDS = new TADOQuery(this);
	DBSQLConn = new TADOConnection(this);
}

// ---------------------------------------------------------------------------
void __fastcall TTrendForm::Button1Click(TObject *Sender) {
	SetView();
	ShowTrends(true);
}

// ---------------------------------------------------------------------------
void __fastcall TTrendForm::Button2Click(TObject *Sender) {
	Form1->SaveTrendConfig();
	TrendForm->Close();
}

// ---------------------------------------------------------------------------
void __fastcall TTrendForm::FormActivate(TObject *Sender) {
	ShowValuesTrends = false;
	ConnectDB(Form1->FileTrendView);
	Cursor = 0;
	if (Form1->ViewRemouteTrends)
	{
		try
		{
			String ConnString ="Provider=SQLOLEDB.1;";
			ConnString +="Data Source=%s;Initial Catalog=%s;User Id=%s;Password=%s;";

			String UserName = Form1->Edit1->Text;
			String PassWord = Form1->MaskEdit1->Text;
			String Server = Form1->ComboBox4->Text+"\\ASUTP_OPCSERVER";
			String BD = Form1->TrendFile[Form1->SelectedTrend];
			ConnString = Format(ConnString, ARRAYOFCONST((Server, BD, UserName, PassWord)));
			DBSQLConn->ConnectionString = ConnString;
			ParamsDS->Connection = DBSQLConn;

			AnsiString QueryTrend;
			QueryTrend = "select * from params";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
			ParamsDS->SQL->Clear();
			ParamsDS->SQL->Add(QueryTrend);
			ParamsDS->Open();
			MaxTrends=ParamsDS->RecordCount;
			ParamsDS->Close();
			DBSQLConn->Close();
		} catch (...)
		{
		}
	}
	else
	{
		MaxTrends = Form1->ListTrends[Form1->SelectedTrend].NumVar; // 64;//12;//
	}

	MaxTrendPoints = 100000;
	MaxViewTrendPoints = 4000;
	ScaleX = 1;
	ScaleY = 1;
	SelectedParam = 0;
	TrendsListGenerate = false;
	SetViewMode(RadioButton1->Checked);
	NumRecordStart = 0;
	SetView();

	int nTr = 9;
	nTable = -1;
	if (!Form1->ViewRemouteTrends) {
		TablesDS->Open();
		TablesDS->Last();
		AnsiString RecordCountFieldTables = "recordcount";
		// RecordCountFieldTables.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
		while ((!TablesDS->Bof) && (nTable == -1)) {
			int nr = TablesDS->Fields->FieldByName(RecordCountFieldTables)
			->AsInteger;
			if (nr > 0) {
				nTable = nTr;
			}
			else {
				TablesDS->Prior();
				nTr--;
			}
		}
	}
	if (nTable == -1)
		nTable = 0;
	AnsiString QueryTrend = "select * from ";
	QueryTrend.operator += (Form1->ListTrends[Form1->SelectedTrend].TableName);
	QueryTrend.operator += (Form1->ListTrends[Form1->SelectedTrend]
		.TableNamePrefix[nTable]);
	QueryTrend.operator += (" order by id asc");
	TrendsDS_Thread->SQL->Clear();
	TrendsDS_Thread->SQL->Add(QueryTrend);
	TrendsDS_Cursor->SQL->Clear();
	TrendsDS_Cursor->SQL->Add(QueryTrend);

	LoadTrends(true);
	ShowTrends(true);
	TLoadTrendsThread *ThrLoadTrends = new TLoadTrendsThread(true);
	StopLoadTrendsThread = false;
	(ThrLoadTrends->Resume());
}
// ---------------------------------------------------------------------------

void TTrendForm::SetView() {
	TrendsListGenerate = true;
	GroupBox1->Top = TrendForm->Height - GroupBox1->Height - 28;
	GroupBox1->Left = 8;
	GroupBox1->Width = TrendForm->Width - GroupBox1->Left * 2 - 6;
	Button2->Left = GroupBox1->Width - Button2->Width - 10;

	StringGrid1->ColWidths[0] = 130;
	StringGrid1->ColWidths[1] = 50;
	StringGrid1->ColWidths[2] = 30;
	StringGrid1->ColWidths[3] = 50;
	// StringGrid1->ColWidths[3]=30;
	// StringGrid1->ColWidths[4]=30;

	// StringGrid1->ColWidths[0]=StringGrid1->Width*5/10;
	// StringGrid1->ColWidths[1]=StringGrid1->Width*3/10;
	// StringGrid1->ColWidths[2]=StringGrid1->Width*1/10;
	StringGrid1->Height = GroupBox1->Top - StringGrid1->Top;

	Image2->Left = StringGrid1->Left + StringGrid1->Width;
	Image2->Width = 40;
	Image2->Top = Image1->Top;

	Image3->Left = StringGrid1->Left + StringGrid1->Width + Image2->Width;
	Image3->Width = GroupBox1->Width - StringGrid1->Width - Image2->Width -
		BitBtn1->Width - 5;
	Image3->Height = 30;
	Image2->Height = GroupBox1->Top - Image3->Height;
	Image3->Top = Image2->Top + Image2->Height;

	Image1->Left = Image2->Left + Image2->Width;
	Image1->Width = Image3->Width;
	Image1->Height = Image2->Height;

	ProgressBar1->Left = GroupBox1->Left;
	ProgressBar1->Top = GroupBox1->Top;
	ProgressBar1->Width = GroupBox1->Width;
	MaxX = Image1->Width;
	MaxY = Image1->Height;
	Image2->Height++;
	Image3->Width += 5;
	Image3->Top++;
	Image1->Height++;
	Image1->Width += 5;
	Image4->Top = Image2->Top + Image2->Height;
	Image4->Left = Image2->Left;
	Image4->Width = Image2->Width;
	Image4->Height = Image3->Height;

	Image5->Left = Image1->Left;
	Image5->Top = Image1->Top;
	Image5->Width = Image1->Width;
	Image5->Height = Image1->Height;
	// Image5->Visible=true;

	BitBtn1->Left = Image1->Left + Image1->Width + 5;
	BitBtn1->Top = Image1->Top;
	BitBtn11->Left = BitBtn1->Left;
	BitBtn12->Left = BitBtn1->Left;
	BitBtn3->Left = BitBtn1->Left;
	BitBtn4->Left = BitBtn1->Left;
	BitBtn5->Left = BitBtn1->Left;
	BitBtn2->Left = BitBtn1->Left;
	BitBtn2->Top = Image3->Top + Image3->Height - BitBtn2->Height;
	BitBtn12->Top = BitBtn1->Top + BitBtn1->Height + 5;
	BitBtn11->Top = BitBtn2->Top - BitBtn11->Height - 5;

	BitBtn4->Top = (BitBtn1->Top + BitBtn2->Top) / 2;
	BitBtn5->Top = BitBtn4->Top - BitBtn5->Height - 30;
	BitBtn3->Top = BitBtn4->Top + BitBtn4->Height + 30;

	BitBtn6->Left = Image1->Left;
	BitBtn7->Left = Button2->Left - BitBtn7->Width - 30;

	BitBtn13->Left = BitBtn6->Left + BitBtn6->Width + 5;
	BitBtn14->Left = BitBtn7->Left - BitBtn14->Width - 5;

	BitBtn9->Left = (BitBtn6->Left + BitBtn7->Left) / 2;
	BitBtn10->Left = BitBtn9->Left - BitBtn10->Width - 30;
	BitBtn8->Left = BitBtn9->Left + BitBtn9->Width + 30;

	AnsiString sc = "1 : ";
	sc.operator += (IntToStr(ScaleX));
	BitBtn9->Caption = sc;
	sc.operator += (IntToStr(ScaleY));
	BitBtn4->Caption = sc;
	TrendForm->Repaint();
	TrendsListGenerate = false;
}
// ---------------------------------------------------------------------------

void TTrendForm::LoadTrends(bool LoadDBData) {
	float y;
	int j, i;
	for (i = 0; i < MaxTrendPoints; i++) {
		for (j = 0; j < MaxTrends; j++) {
			PointsTrends[j].Y[i] = 0;
		}
	}

	if (Form1->ViewRemouteTrends)
	{
		try
		{
			String ConnString ="Provider=SQLOLEDB.1;";
			ConnString +="Data Source=%s;Initial Catalog=%s;User Id=%s;Password=%s;";

			String UserName = Form1->Edit1->Text;
			String PassWord = Form1->MaskEdit1->Text;
			String Server = Form1->ComboBox4->Text+"\\ASUTP_OPCSERVER";
			String BD = Form1->TrendFile[Form1->SelectedTrend];
			ConnString = Format(ConnString, ARRAYOFCONST((Server, BD, UserName, PassWord)));
			DBSQLConn->ConnectionString = ConnString;
			ValuesDS->Connection = DBSQLConn;
			AnsiString QueryTrend;
			QueryTrend = "select * from vals";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
			ValuesDS->SQL->Clear();
			ValuesDS->SQL->Add(QueryTrend);
			ValuesDS->Open();
			NumTrendRecords = ValuesDS->RecordCount;
			NumTrendPoints = 0;
			ValuesDS->Last();
			while ((!ValuesDS->Bof)&&(NumTrendPoints < MaxViewTrendPoints))
			{

            }
		} catch (...)
		{
		}
	}
	else
	{
		TrendsDS_Thread->Open();
		NumTrendRecords = TrendsDS_Thread->RecordCount;
		NumTrendPoints = 0;
		float FloatVal = -2;
		int IntVal = -1;
		bool BoolVal = false;
		bool FirstIter = true;
		ProgressBar1->Max = MaxViewTrendPoints;
		ProgressBar1->Min = NumTrendPoints;
		TrendsDS_Thread->Last();
		AnsiString IdField = Form1->TTrends[Form1->SelectedTrend].IdField;
		AnsiString DateField = Form1->TTrends[Form1->SelectedTrend].DateField;
		long int PosId = TrendsDS_Thread->FieldByName(IdField)->AsInteger;
		while (((!TrendsDS_Thread->Bof)||(nTable > 0))&&(NumTrendPoints < MaxViewTrendPoints))
		{
			TrendsDateTime[NumTrendPoints] = TrendsDS_Thread->FieldByName(DateField)->AsDateTime;
			nRecords[NumTrendPoints] = TrendsDS_Thread->FieldByName(IdField)->AsInteger;
			nTables[NumTrendPoints] = nTable;
			for (j = 0; j < MaxTrends; j++) // 1;j++)//
			{
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 0)
				{
					FloatVal = TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					y = FloatVal;
					if (FirstIter)
					{
						PointsTrends[j].TypeVal = 0;
						PointsTrends[j].FloatCurrentVal = FloatVal;
					}
				}
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 1)
				{
					IntVal = (int)TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					y = IntVal;
					if (FirstIter)
					{
						PointsTrends[j].TypeVal = 1;
						PointsTrends[j].IntCurrentVal = IntVal;
					}
				}
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 2)
				{
					BoolVal = (bool)TrendsDS_Thread->FieldByName(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])->AsFloat;
					if (BoolVal)
						y = 250;
					else
						y = 50;
					if (FirstIter)
					{
						PointsTrends[j].TypeVal = 2;
						PointsTrends[j].BoolCurrentVal = BoolVal;
					}
				}
				PointsTrends[j].Y[NumTrendPoints] = y;
			}
			TrendsDS_Thread->Prior();
			if (TrendsDS_Thread->Bof)
			{
				if (nTable > 0)
				{
					nTable--;
					AnsiString QueryTrend = "select * from ";
					QueryTrend.operator+=(Form1->ListTrends[Form1->SelectedTrend].TableName);
					QueryTrend.operator+=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[nTable]);
					QueryTrend.operator += (" order by id asc");
					TrendsDS_Thread->SQL->Clear();
					TrendsDS_Thread->SQL->Add(QueryTrend);
					TrendsDS_Thread->Open();
					NumTrendRecords += TrendsDS_Thread->RecordCount;
					TrendsDS_Thread->Last();
				}
			}
			NumTrendPoints++;
			ProgressBar1->Position = NumTrendPoints;
			FirstIter = false;
		}
	}
	NumViewTrendPoints = NumTrendPoints;
	ProgressBar1->Position = MaxViewTrendPoints;
}
// ---------------------------------------------------------------------------

void TTrendForm::ShowTrends(bool LoadDBData) {
	TrendsListGenerate = true;

	int rec1 = int(NumRecordStart / ScaleX);
	if (rec1 < MaxX)
		NumRecordStart = MaxX * ScaleX;
	if (NumRecordStart > NumTrendRecords)
		NumRecordStart = NumTrendRecords - 1;
	NumViewTrendPoints = 0;
	int y, i, j;
	float y1 = 0, y2 = 0, y3 = 0;
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////

	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////

	for (j = 0; j < MaxTrends; j++) {
		int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[j];
		int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[j];
		int sc = cmax - cmin;
		ViewTrends[j].YRatio = (float)MaxY / sc;
		ViewTrends[j].YRatio = (float)MaxY / sc;
	}

	for (i = 0; i < MaxX; i++) {
		long int n = NumRecordStart - i * ScaleX;
		nViewRecords[i] = nRecords[n];
		nViewTables[i] = nTables[n];

		if (n < 0)
			break;
		ViewTrendsDateTime[i] = TrendsDateTime[n];
		for (j = 0; j < MaxTrends; j++) {
			// if (j==0)
			// {
			// y = (PointsTrends[j].Y[n]-Form1->ListTrends[Form1->SelectedTrend].Y[j]+-Form1->ListTrends[Form1->SelectedTrend].MinY[j])*ViewTrends[j].YRatio;
			y1 = (float)((float)PointsTrends[j].Y[n] - (float)
				Form1->ListTrends[Form1->SelectedTrend].Y[j] - (float)
				Form1->ListTrends[Form1->SelectedTrend].MinY[j]);
			y2 = (float)((float)ViewTrends[j].YRatio);
			y3 = (float)((float)y1 * (float)y2);
			y1 = (float)((float)y3 * (float)10);
			y2 = (float)((float)y1 / (float)Form1->ListTrends
				[Form1->SelectedTrend].ScaleY[j]);
			y3 = (float)((float)MaxY - (float)y2);
			ViewTrends[j].Points[i].y = (int)(y3);
			ViewTrends[j].Points[i].x = i;
			// }
		}
		NumViewTrendPoints++;
	}

	if (Form1->ViewRemouteTrends)
	{
		try
		{
		} catch (...)
		{
		}
	}
	else
	{
		TrendsDS_Cursor->Open();
		AnsiString QueryTrend = "select * from ";
		QueryTrend.operator += (Form1->ListTrends[Form1->SelectedTrend].TableName);
		QueryTrend.operator += (Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[nViewTables[Cursor]]);
		QueryTrend.operator += (" order by id asc");
		TrendsDS_Cursor->SQL->Clear();
		TrendsDS_Cursor->SQL->Add(QueryTrend);
		TrendsDS_Cursor->Open();
		HRESULT hr = TrendsDS_Cursor->Locate("id", nViewRecords[Cursor],TLocateOptions() << loCaseInsensitive);
		if (SUCCEEDED(hr))
		{
			for (j = 0; j < MaxTrends; j++)
			{
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 0)
					PointsTrends[j].FloatCursorVal = TrendsDS_Cursor->FieldByName
					(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])
					->AsFloat;
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 1)
					PointsTrends[j].IntCursorVal = (int)TrendsDS_Cursor->FieldByName
					(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])
					->AsFloat;
				if (Form1->TTrends[Form1->SelectedTrend].TypeField[j] == 2)
					PointsTrends[j].BoolCursorVal = (bool)
					TrendsDS_Cursor->FieldByName
					(Form1->TTrends[Form1->SelectedTrend].NameFieldDB[j])
					->AsFloat;
			}
		}
		TrendsDS_Cursor->Close();
	}

	//////////////////////////////////////////////////////////////////
	// ����� �������
	//////////////////////////////////////////////////////////////////
	Image4->Canvas->Brush->Color = Form1->BackColor;
	Image4->Canvas->FillRect(Rect(0, 0, Image4->Width, Image4->Height));

	Image2->Canvas->Brush->Color = Form1->BackColor;
	Image2->Canvas->FillRect(Rect(0, 0, Image2->Width, Image2->Height));
	Image2->Canvas->Pen->Width = 1;
	Image2->Canvas->Pen->Color = Form1->GrayColor;
	Image2->Canvas->Pen->Style = psDot;
	Image2->Canvas->Font->Color = Form1->Colors[2];

	Image3->Canvas->Brush->Color = Form1->BackColor;
	Image3->Canvas->FillRect(Rect(0, 0, Image3->Width, Image3->Height));
	Image3->Canvas->Pen->Width = 1;
	Image3->Canvas->Pen->Color = Form1->GrayColor;
	Image3->Canvas->Pen->Style = psDot;
	Image3->Canvas->Font->Color = Form1->Colors[2];

	Image1->Canvas->Brush->Color = Form1->BackColor;
	Image1->Canvas->FillRect(Rect(0, 0, Image1->Width, Image1->Height));
	// ���������� ���� �������
	Image1->Canvas->Pen->Width = 1;
	Image1->Canvas->Pen->Color = Form1->GrayColor;
	Image1->Canvas->Pen->Style = psDot;
	Image1->Canvas->Font->Color = Form1->Colors[2];
	if (SelectedParam <= 0)
		SelectedParam = 1;
	int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[SelectedParam - 1];
	int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[SelectedParam - 1];
	int sc = cmax - cmin;
	if (sc <= 0)
		sc = 500;
	// int ci=0;
	// if (cmin<0)
	// {
	// ci=6+sc/cmin;
	// }
	int cy = Form1->ListTrends[Form1->SelectedTrend].Y[SelectedParam - 1];
	float dsc = sc; // *10;
	dsc = (float)((float)dsc / (float)5);
	int ysc = cmin + cy;
	int scy = Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1];
	int nr = 5;
	for (int i = 0; i <= nr; i++) {
		float dysc;
		dysc = (float)((float)dsc * (float)i); // -ci);
		dysc = (float)((float)dysc * (float)scy);
		dysc = (float)((float)dysc / (float)10);
		// dysc=dysc/10;
		int Y = MaxY - (int)(i * MaxY / nr);
		Image1->Canvas->PenPos = TPoint(0, Y);
		Image1->Canvas->LineTo(MaxX + 5, Y);
		Image2->Canvas->PenPos = TPoint(0, Y);
		Image2->Canvas->LineTo(MaxX, Y);
		int dyr = 0;
		if (i < nr)
			dyr = 15;
		else
			dyr = -5;
		AnsiString str2;
		str2.printf("%.1f", (float)((float)ysc + (float)dysc));
		Image2->Canvas->TextOutA(5, Y - dyr, str2); // IntToStr(ysc+dysc));
	}
	AnsiString sDateOld = "";
	int nc = 8;
	for (int i = 0; i <= nc; i++) {
		long int n = (int)(float)(i * MaxX / nc);
		if (n > 0)
			n--;
		if (int(n * ScaleX) >= NumTrendPoints)
			break;
		AnsiString sDate = ViewTrendsDateTime[n].DateString();
		AnsiString sTime = ViewTrendsDateTime[n].TimeString();
		AnsiString sDateTime = ViewTrendsDateTime[n].DateTimeString();
		int x = (int)i * MaxX / nc;
		int dxc = 0;
		if (i < nc)
			dxc = 2;
		else
			dxc = -60;
		Image3->Canvas->TextOutA(x + dxc, 2, sTime);
		Image3->Canvas->TextOutA(x + dxc, 13, sDate);
		Image1->Canvas->PenPos = TPoint(x, 0);
		Image1->Canvas->LineTo(x, MaxY);
		Image3->Canvas->PenPos = TPoint(x, 0);
		Image3->Canvas->LineTo(x, MaxY);
		sDateOld = sDate;
	}

	Image1->Canvas->Pen->Color = Form1->Colors[2];
	Image1->Canvas->Pen->Style = psDashDotDot; // psDot;
	Image1->Canvas->PenPos = TPoint(Cursor, 0);
	Image1->Canvas->LineTo(Cursor, MaxY);

	for (int j = 0; j < MaxTrends; j++) // 1;j++)//
	{
		if (Form1->ListTrends[Form1->SelectedTrend].Visible[j]) {
			// ��� �����
			Image1->Canvas->Pen->Style = psSolid;
			Image1->Canvas->Pen->Color = Form1->Colors
				[Form1->ListTrends[Form1->SelectedTrend].Color[j]];
			if (j == (SelectedParam - 1))
				Image1->Canvas->Pen->Width = 4;
			else
				Image1->Canvas->Pen->Width = 2;
			// ����� �����
			Image1->Canvas->Polyline(ViewTrends[j].Points,
				NumViewTrendPoints - 1);
		}
	}
	//////////////////////////////////////////////////////////////////
	// ������������ ������ �������
	//////////////////////////////////////////////////////////////////
	Label7->Caption = ViewTrendsDateTime[Cursor].DateTimeString();
	StringGrid1->Rows[0]->Clear();
	StringGrid1->RowCount = 0;
	if (Form1->ViewRemouteTrends)
	{
		try
		{
			ParamsDS->First();
			for (int j = 0; j < MaxTrends; j++) // 1;j++)//
			{
				StringGrid1->RowCount = j + 1;
				StringGrid1->Cells[0][j] = ParamsDS[Form1->SelectedTrend].FieldByName("name")->AsAnsiString;
				ParamsDS->Next();
			}
		} catch (...)
		{
		}
	}
	else
	{
		for (int j = 0; j < MaxTrends; j++) // 1;j++)//
		{
			StringGrid1->RowCount = j + 1;
			StringGrid1->Cells[0][j] = Form1->TTrends[Form1->SelectedTrend].AboutField[j];
		}
	}
	for (int j = 0; j < MaxTrends; j++) // 1;j++)//
	{
		if (PointsTrends[j].TypeVal == 0) {
			AnsiString str1;
			str1.printf("%.2f", PointsTrends[j].FloatCurrentVal);
			StringGrid1->Cells[3][j] = str1; // PointsTrends[j].FloatCurrentVal;
			str1.printf("%.2f", PointsTrends[j].FloatCursorVal);
			StringGrid1->Cells[1][j] = str1; // PointsTrends[j].FloatCursorVal;
		}
		if (PointsTrends[j].TypeVal == 1) {
			StringGrid1->Cells[3][j] = PointsTrends[j].IntCurrentVal;
			StringGrid1->Cells[1][j] = PointsTrends[j].IntCursorVal;
		}
		if (PointsTrends[j].TypeVal == 2) {
			if (PointsTrends[j].BoolCurrentVal)
				StringGrid1->Cells[3][j] = "true";
			else
				StringGrid1->Cells[3][j] = "false";

			if (PointsTrends[j].BoolCursorVal)
				StringGrid1->Cells[1][j] = "true";
			else
				StringGrid1->Cells[1][j] = "false";
		}
	}
	// �������
	AnsiString sca = "1 : ";
	sca.operator += (IntToStr(ScaleX));
	BitBtn9->Caption = sca;
	sca = "10 : ";
	sca.operator += (IntToStr(Form1->ListTrends[Form1->SelectedTrend].ScaleY
			[SelectedParam - 1]));
	BitBtn4->Caption = sca;
	Image5->Canvas->CopyRect(Rect(0, 0, Image1->Width, Image1->Height),
		Image1->Canvas, Rect(0, 0, Image1->Width, Image1->Height));
	// Image5->Repaint();
	// Image2->Repaint();
	// Image3->Repaint();
	// Image4->Repaint();
	TrendsListGenerate = false;
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::RadioButton1Click(TObject *Sender) {
	SetViewMode(RadioButton1->Checked);
	SetView();
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::RadioButton2Click(TObject *Sender) {
	SetViewMode(RadioButton1->Checked);
	SetView();
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void TTrendForm::SetViewMode(bool Mode) {
	ViewMode = Mode;
	if (ViewMode) {
		Form1->BackColor = Form1->BlackColor;
		Form1->Colors[2] = clWhite; // clBlack;
	}
	else {
		Form1->BackColor = Form1->WhiteColor;
		Form1->Colors[2] = clBlack;
	}
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::StringGrid1DrawCell(TObject *Sender, int ACol,
	int ARow, TRect &Rect, TGridDrawState State) {
	if ((ACol == 0)) {
		if ((SelectedParam - 1) != ARow) {
			StringGrid1->Canvas->Brush->Color = clWhite;
			StringGrid1->Canvas->Font->Color = clBlack;
		}
		else {
			StringGrid1->Canvas->Brush->Color = clBlue;
			StringGrid1->Canvas->Font->Color = clWhite;
		}
		StringGrid1->Canvas->FillRect(Rect);
		StringGrid1->Canvas->TextOut(Rect.Left, Rect.Top,
			StringGrid1->Cells[ACol][ARow]);
	}
	if ((ACol == 1) || (ACol == 3)) // ||(ACol==4))
	{
		StringGrid1->Canvas->Font->Color = clBlack;
		if (Form1->ListTrends[Form1->SelectedTrend].Visible[ARow])
			StringGrid1->Canvas->Brush->Color = clWhite; // clGreen;
		else
			StringGrid1->Canvas->Brush->Color = clMedGray;
		StringGrid1->Canvas->FillRect(Rect);
		StringGrid1->Canvas->TextOut(Rect.Left, Rect.Top,
			StringGrid1->Cells[ACol][ARow]);
	}
	if (ACol == 2) {
		StringGrid1->Canvas->Brush->Color = Form1->Colors
			[Form1->ListTrends[Form1->SelectedTrend].Color[ARow]];
		StringGrid1->Canvas->FillRect(Rect);
		StringGrid1->Canvas->TextOut(Rect.Left, Rect.Top,
			StringGrid1->Cells[ACol][ARow]);
	}
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::StringGrid1SelectCell(TObject *Sender, int ACol,
	int ARow, bool &CanSelect) {
	if (!TrendsListGenerate) {
		SelectedParam = ARow + 1;
		ShowTrends(false);
		Form1->SelectedParam = ARow;
	}
	if (ACol == 0) {
	}
	if (ACol == 1) {
		Form1->ListTrends[Form1->SelectedTrend].Visible[SelectedParam - 1]
			^= true;
		ShowTrends(false);
	}
	if ((ACol == 2) || (ACol == 3) || (ACol == 4)) {
		SelectColorForm->ShowModal();
		ShowTrends(false);
	}
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::Button5Click(TObject *Sender) {
	ScaleX = 1;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::FormClose(TObject *Sender, TCloseAction &Action) {
	StopLoadTrendsThread = true;
	TrendsDS_Cursor->Close();
	ADOConnection1->Close();
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn1Click(TObject *Sender) {
	int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[SelectedParam - 1];
	int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[SelectedParam - 1];
	int sc = cmax - cmin;
	if (sc <= 0)
		sc = 600;
	int dsc = sc / 5;
	Form1->ListTrends[Form1->SelectedTrend].Y[SelectedParam - 1] -= dsc;
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn2Click(TObject *Sender) {
	int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[SelectedParam - 1];
	int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[SelectedParam - 1];
	int sc = cmax - cmin;
	if (sc <= 0)
		sc = 600;
	int dsc = sc / 5;
	Form1->ListTrends[Form1->SelectedTrend].Y[SelectedParam - 1] += dsc;
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn3Click(TObject *Sender) {
	if (Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1] < 20)
	{
		Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1]++;
	}
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn4Click(TObject *Sender) {
	Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1] = 10;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn5Click(TObject *Sender) {
	if (Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1] > 1) {
		Form1->ListTrends[Form1->SelectedTrend].ScaleY[SelectedParam - 1]--;
	}
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn6Click(TObject *Sender) {
	NumRecordStart += MaxX / 4 * ScaleX;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn7Click(TObject *Sender) {
	NumRecordStart -= MaxX / 4 * ScaleX;
	if (NumRecordStart < 0)
		NumRecordStart = 0;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn8Click(TObject *Sender) {
	if (ScaleX > 1) {
		ScaleX -= 1;
	}
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn10Click(TObject *Sender) {
	if (ScaleX < 20) {
		ScaleX += 1;
	}
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn9Click(TObject *Sender) {
	ScaleX = 1;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn13Click(TObject *Sender) {
	NumRecordStart += MaxX / 8 * ScaleX;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn14Click(TObject *Sender) {
	NumRecordStart -= MaxX / 8 * ScaleX;
	if (NumRecordStart < 0)
		NumRecordStart = 0;
	ShowTrends(true);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn12Click(TObject *Sender) {
	int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[SelectedParam - 1];
	int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[SelectedParam - 1];
	int sc = cmax - cmin;
	if (sc <= 0)
		sc = 600;
	int dsc = sc / 20;
	Form1->ListTrends[Form1->SelectedTrend].Y[SelectedParam - 1] -= dsc;
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::BitBtn11Click(TObject *Sender) {
	int cmax = Form1->ListTrends[Form1->SelectedTrend].MaxY[SelectedParam - 1];
	int cmin = Form1->ListTrends[Form1->SelectedTrend].MinY[SelectedParam - 1];
	int sc = cmax - cmin;
	if (sc <= 0)
		sc = 600;
	int dsc = sc / 20;
	Form1->ListTrends[Form1->SelectedTrend].Y[SelectedParam - 1] += dsc;
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void TTrendForm::ConnectDB(String pth) {
	if (Form1->ViewRemouteTrends) {
		String ConnString = "Provider=SQLOLEDB.1;";
		ConnString +=
			"Data Source=%s;Initial Catalog=%s;User Id=%s;Password=%s;";

		String UserName = Form1->Edit1->Text;
		String PassWord = Form1->MaskEdit1->Text;
		String Server = Form1->ComboBox4->Text + "\\ASUTP_OPCSERVER";
		String BD = Form1->TrendFile[Form1->SelectedTrend];
		ConnString = Format(ConnString,
			ARRAYOFCONST((Server, BD, UserName, PassWord)));
		ADOConnection1->ConnectionString = ConnString;
	}
	else {
		String pr, dpr;
		pr = "MSDataShape.1";
		dpr = "Microsoft.Jet.OLEDB.4.0";
		String tmp = pth;
		const String ConnStr = "Provider=%s;Data Provider=%s;Data Source=%s";
		ADOConnection1->ConnectionString = Format(ConnStr,
			ARRAYOFCONST((pr, dpr, tmp)));
	}
}

void __fastcall TTrendForm::Image5MouseDown(TObject *Sender,
	TMouseButton Button, TShiftState Shift, int X, int Y) {
	Cursor = X;
	ShowTrends(false);
}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::Image5MouseMove(TObject *Sender, TShiftState Shift,
	int X, int Y) {
	Image5->Canvas->CopyRect(Rect(0, 0, Image1->Width, Image1->Height),
		Image1->Canvas, Rect(0, 0, Image1->Width, Image1->Height));
	Image1->Canvas->Brush->Color = Form1->BackColor;
	Image5->Canvas->Pen->Color = Form1->Colors[1];
	Image5->Canvas->Pen->Style = psDash; // psClear;//psSolid;//psDot;//
	Image5->Canvas->PenPos = TPoint(X, 0);
	Image5->Canvas->LineTo(X, MaxY);
	int n = 0;
	for (int i = 0; i < MaxTrends; i++) {
		if (Form1->ListTrends[Form1->SelectedTrend].Visible[i]) {
			int dy = abs(ViewTrends[i].Points[X].y - Y - 1);
			if (dy < 5) {
				Image5->Canvas->Brush->Color = Form1->BackColor;
				Image5->Canvas->Font->Color = Form1->Colors
					[Form1->ListTrends[Form1->SelectedTrend].Color[i]];
				Image5->Canvas->Font->Size = 12;
				TFontStyles tFontStyle;
				tFontStyle << fsBold << fsUnderline;
				Image5->Canvas->Font->Style = tFontStyle;
				Image5->Canvas->Font->Name = "Times";

				AnsiString str1 = StringGrid1->Cells[0][i];

				if (ShowValuesTrends) {
					AnsiString str2 = "";
					str1.operator += ("  :  ");
					TrendsDS_Cursor->Open();
					AnsiString QueryTrend = "select * from ";
					QueryTrend.operator +=
						(Form1->ListTrends[Form1->SelectedTrend].TableName);
					QueryTrend.operator +=
						(Form1->ListTrends[Form1->SelectedTrend]
						.TableNamePrefix[nViewTables[X]]);
					QueryTrend.operator += (" order by id asc");
					TrendsDS_Cursor->SQL->Clear();
					TrendsDS_Cursor->SQL->Add(QueryTrend);
					TrendsDS_Cursor->Open();
					HRESULT hr = TrendsDS_Cursor->Locate("id", nViewRecords[X],
						TLocateOptions() << loCaseInsensitive);
					float FloatVal;
					int IntVal;
					bool BoolVal;
					if (SUCCEEDED(hr)) {
						str2.printf("%.2f",
							TrendsDS_Cursor->FieldByName
							(Form1->TTrends[Form1->SelectedTrend]
								.NameFieldDB[i])->AsFloat);
					}
					TrendsDS_Cursor->Close();
					str1.operator += (str2);
				}
				int dn = 1;
				if ((float)Y > (float)(MaxX / 2)) {
					dn = -1;
				}
				Image5->Canvas->TextOutA(X + 20, Y + (25 + 18 * n) * dn, str1);
				n++;
			}
		}
	}

	// Image5->Repaint();

}
// ---------------------------------------------------------------------------

void __fastcall TTrendForm::CheckBox1Click(TObject *Sender) {
	ShowValuesTrends = CheckBox1->Checked;
}
// ---------------------------------------------------------------------------
