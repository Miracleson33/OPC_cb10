//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "selecttrends.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSelectTrendsForm *SelectTrendsForm;
//---------------------------------------------------------------------------
__fastcall TSelectTrendsForm::TSelectTrendsForm(TComponent* Owner)
    : TForm(Owner)
{
	ParamsDS = new TADOQuery(this);
	DBSQLConn = new TADOConnection(this);
}
//---------------------------------------------------------------------------


void __fastcall TSelectTrendsForm::Button1Click(TObject *Sender)
{
	if (SelectedRow3>=0) {
		Form1->SaveTrendConfig();
		Form1->FileTrendView=StringGrid3->Cells[0][SelectedRow3];
		TrendForm->ShowModal();
	}
}
//---------------------------------------------------------------------------
void __fastcall TSelectTrendsForm::Button2Click(TObject *Sender)
{
    SelectTrendsForm->Close();
}
//---------------------------------------------------------------------------
void __fastcall TSelectTrendsForm::FormActivate(TObject *Sender)
{
	SelectedRow=-1;
	StringGrid1->ColWidths[0]=0;
	StringGrid1->ColWidths[1]=StringGrid1->Width-5;
//	StringGrid1->RowCount=Form1->NumListTrends;
	StringGrid1->Cells[0][0]="";
	StringGrid1->Cells[1][0]="";

	StringGrid2->ColWidths[0]=0;
	StringGrid2->ColWidths[1]=90;
	StringGrid2->ColWidths[2]=30;
	StringGrid2->ColWidths[3]=40;
	StringGrid2->ColWidths[4]=40;
	StringGrid2->RowCount=0;
	StringGrid2->Cells[0][0]="";
	StringGrid2->Cells[1][0]="";

	StringGrid3->ColWidths[0]=0;
	StringGrid3->ColWidths[1]=StringGrid3->Width-3;
	int n=0;
	for (int i=0;i<Form1->NumListTrends;i++)
	{
		n++;
		StringGrid1->RowCount=n;
		StringGrid1->Cells[0][n-1]=Form1->ListTrends[i].NTrend;
		StringGrid1->Cells[1][n-1]=Form1->ListTrends[i].TrendName;
	}

	if (StringGrid1->RowCount>0)
	{
		StringGrid1->Col=0;
		StringGrid1->Row=0;
		Form1->SelectedTrend=0;
	}
	else
	{
		SelectedRow=-1;
		Form1->SelectedTrend=-1;
	}
	SelectedRow3=-1;
	if (Form1->ViewRemouteTrends) RadioButton1->Checked=true; else RadioButton2->Checked=true;
//	SelectedRow3=0;
//	StringGrid3->Repaint();
	SetMode(Form1->ViewRemouteTrends);
}
//---------------------------------------------------------------------------
void __fastcall TSelectTrendsForm::StringGrid1DrawCell(TObject *Sender,
	  int ACol, int ARow, TRect &Rect, TGridDrawState State)
{
	StringGrid1->Canvas->Font->Color=clBlack;
	if (ACol==1)
	{
		if (ARow==SelectedRow)
			StringGrid1->Canvas->Brush->Color=clGreen;
		else
			StringGrid1->Canvas->Brush->Color=clMedGray;
			StringGrid1->Canvas->FillRect(Rect);
			StringGrid1->Canvas->TextOut(Rect.Left,Rect.Top,StringGrid1->Cells[ACol][ARow]);

	}
}
//---------------------------------------------------------------------------
void __fastcall TSelectTrendsForm::StringGrid1SelectCell(TObject *Sender,
	  int ACol, int ARow, bool &CanSelect)
{
	if (StringGrid1->Cells[0][ARow]!="")
	{
		SelectedRow=ARow;
		Form1->SelectedTrend=StringGrid1->Cells[0][SelectedRow].ToInt();
		Form1->LoadTrendConfig();
		StringGrid2->Repaint();
		Button1->Enabled=true;
		if (RemouteMode)
		{
			try
			{
				String ConnString ="Provider=SQLOLEDB.1;";
				ConnString +="Data Source=%s;Initial Catalog=%s;User Id=%s;Password=%s;";

				String UserName = Form1->Edit1->Text;
				String PassWord = Form1->MaskEdit1->Text;
				String Server = Form1->ComboBox4->Text+"\\ASUTP_OPCSERVER";
				String BD = Form1->TrendFile[Form1->SelectedTrend];
				ConnString = Format(ConnString, ARRAYOFCONST((Server, BD, UserName, PassWord)));
				DBSQLConn->ConnectionString = ConnString;
				ParamsDS->Connection = DBSQLConn;

				AnsiString QueryTrend;
				QueryTrend = "select * from params";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//				QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
				ParamsDS->SQL->Clear();
				ParamsDS->SQL->Add(QueryTrend);
				ParamsDS->Open();
				ParamsDS->First();
				StringGrid2->RowCount=ParamsDS->RecordCount;
				for (int i=0;i<ParamsDS->RecordCount;i++)
				{
					StringGrid2->Cells[1][i]=ParamsDS->FieldByName("name")->AsAnsiString;
					StringGrid2->Cells[3][i]=Form1->ListTrends[Form1->SelectedTrend].MinY[i];
					StringGrid2->Cells[4][i]=Form1->ListTrends[Form1->SelectedTrend].MaxY[i];
					ParamsDS->Next();
				}
				ParamsDS->Close();
				DBSQLConn->Close();
			} catch (...)
			{
			}
		}
		else
		{
			StringGrid2->RowCount=Form1->ListTrends[Form1->SelectedTrend].NumVar;
			for (int i=0;i<Form1->ListTrends[Form1->SelectedTrend].NumVar;i++)
			{
				StringGrid2->Cells[1][i]=Form1->TTrends[Form1->SelectedTrend].NameField[i];
				StringGrid2->Cells[3][i]=Form1->ListTrends[Form1->SelectedTrend].MinY[i];
				StringGrid2->Cells[4][i]=Form1->ListTrends[Form1->SelectedTrend].MaxY[i];
			}
		}
		if (StringGrid2->RowCount>0) StringGrid2->Enabled=true; else StringGrid2->Enabled=false;
		SetMode(RadioButton1->Checked);
	}
	else
    {
        Button1->Enabled=false;
        StringGrid2->Enabled=false;
    }
	StringGrid1->Repaint();
}
//---------------------------------------------------------------------------
void __fastcall TSelectTrendsForm::StringGrid2DrawCell(TObject *Sender,
      int ACol, int ARow, TRect &Rect, TGridDrawState State)
{
    StringGrid2->Canvas->Font->Color=clBlack;
	if ((ACol==1)||(ACol==3)||(ACol==4))
	{
		if (Form1->ListTrends[Form1->SelectedTrend].Visible[ARow])
		{
			StringGrid2->Canvas->Brush->Color=clGreen;
		}
		else
		{
			StringGrid2->Canvas->Brush->Color=clMedGray;
		}
			StringGrid2->Canvas->FillRect(Rect);
			StringGrid2->Canvas->TextOut(Rect.Left,Rect.Top,StringGrid2->Cells[ACol][ARow]);
	}
	if (ACol==2)
	{
			StringGrid2->Canvas->Brush->Color=Form1->Colors[Form1->ListTrends[Form1->SelectedTrend].Color[ARow]];
			StringGrid2->Canvas->FillRect(Rect);
			StringGrid2->Canvas->TextOut(Rect.Left,Rect.Top,StringGrid2->Cells[ACol][ARow]);
	}
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::StringGrid2SelectCell(TObject *Sender,
      int ACol, int ARow, bool &CanSelect)
{
    if (ACol==1)
		Form1->ListTrends[Form1->SelectedTrend].Visible[ARow]^=true;
    if ((ACol==2)||(ACol==3)||(ACol==4))
	{
		Form1->SelectedParam=ARow;
		SelectColorForm->ShowModal();
	}
	StringGrid2->Repaint();
}
//---------------------------------------------------------------------------


void __fastcall TSelectTrendsForm::FileListBox1Click(TObject *Sender)
{
	Form1->FileTrendView=FileListBox1->Items->Strings[FileListBox1->ItemIndex];
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::SetMode(bool RM)
{
 /*	RemouteMode=RM;
if (Form1->SelectedTrend>=0)
{
	for (int i = 0; i < FileListBox1->Count; i++)
	{
		FileListBox1->Items->Strings[i]="";
	}
	for (int i = 0; i < StringGrid3->RowCount; i++)
	{
		StringGrid3->Cells[0][i]="";
		StringGrid3->Cells[1][i]="";
	}
	AnsiString DateField=Form1->TTrends[Form1->SelectedTrend].DateField;
	if (RemouteMode)
	{
		try
		{
			String ConnString ="Provider=SQLOLEDB.1;";
			ConnString +="Data Source=%s;Initial Catalog=%s;User Id=%s;Password=%s;";

			String UserName = Form1->Edit1->Text;
			String PassWord = Form1->MaskEdit1->Text;
//			String Server = Form1->ComboBox4->Text+"\\ASUTP_OPCSERVER";
			String Server = Form1->ComboBox4->Text+"\\OPCSERVERASUTP1";
			String BD = Form1->TrendFile[Form1->SelectedTrend];
			ConnString = Format(ConnString, ARRAYOFCONST((Server, BD, UserName, PassWord)));
			DBSQLConn->ConnectionString = ConnString;
			ParamsDS->Connection = DBSQLConn;

			AnsiString QueryTrend;
			QueryTrend = "select * from tables";
			TablesDS[idTrend]->SQL->Clear();
			TablesDS[idTrend]->SQL->Add(QueryTrend);
			TablesDS[idTrend]->Open();
			TablesDS[idTrend]->First();
			TDateTime d1=TablesDS->FieldByName("starttime")->AsDateTime;
			TDateTime d2=TablesDS->FieldByName("endtime")->AsDateTime;
			while (!TablesDS[idTrend]->Eof)
			{
				if (TablesDS[idTrend]->FieldByName("reccount")->AsInteger<Form1->RecordsInTable)
				{
					NT=TablesDS[idTrend]->FieldByName("valtable")->AsString.ToInt();
					idT=TablesDS[idTrend]->FieldByName("id")->AsInteger;
				}
				TablesDS[idTrend]->Next();
			}
			TablesDS[idTrend]->Close();

			QueryTrend = "select top 1 * from vals";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
			QueryTrend.operator +=(" order by ");
			QueryTrend.operator +=("id");
			QueryTrend.operator +=(" desc");
			ParamsDS->SQL->Clear();
			ParamsDS->SQL->Add(QueryTrend);
			ParamsDS->Open();
			TDateTime d2=ParamsDS->FieldByName(DateField)->AsDateTime;
			ParamsDS->Close();
			DBSQLConn->Close();

			AnsiString st1=d1.DateTimeString();
			if (!st1.AnsiCompareIC("30.12.1899")) st1=" ?";
			AnsiString st2=d2.DateTimeString();
			if (!st2.AnsiCompareIC("30.12.1899")) st2=" ?";
			AnsiString st=st1;
			st.operator +=(" - ");
			st.operator +=(st2);
			StringGrid3->RowCount=1;
			StringGrid3->Cells[1][0]=st;

		} catch (...)
		{
		}
	}
	else
	{
		String st=Form1->FullTrendPath[Form1->SelectedTrend];
		FileListBox1->Directory=st;
		FileListBox1->Update();
		StringGrid3->RowCount=FileListBox1->Count+1;
		for (int i = 0; i < StringGrid3->RowCount; i++)
		{
			try {
			AnsiString FileTrend;
			if (i==0)
			{
				FileTrend=Form1->FullTrendFilePath[Form1->SelectedTrend];
			}
			else
			{
				FileTrend=FileListBox1->Items->Strings[i-1];
			}
			StringGrid3->Cells[0][i]=FileTrend;

			String pr,dpr;
			pr="MSDataShape.1";
			dpr="Microsoft.Jet.OLEDB.4.0";
			const String ConnStr = "Provider=%s;Data Provider=%s;Data Source=%s";
			DBSQLConn->ConnectionString = Format (ConnStr,	ARRAYOFCONST((pr,dpr,FileTrend)));
			ParamsDS->Connection = DBSQLConn;

			AnsiString QueryTrend;
			QueryTrend = "select top 1 * from ";
			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
//			QueryTrend = "select * from ";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[0]);
			ParamsDS->SQL->Clear();
			ParamsDS->SQL->Add(QueryTrend);
			ParamsDS->Open();
			ParamsDS->First();
			TDateTime d1=ParamsDS->FieldByName(DateField)->AsDateTime;
			ParamsDS->Close();

			QueryTrend = "select top 1 * from ";
			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[9]);
			QueryTrend.operator +=(" order by ");
			QueryTrend.operator +=("id");
			QueryTrend.operator +=(" desc");
//			QueryTrend = "select * from ";
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableName);
//			QueryTrend.operator +=(Form1->ListTrends[Form1->SelectedTrend].TableNamePrefix[9]);
			ParamsDS->SQL->Clear();
			ParamsDS->SQL->Add(QueryTrend);
			ParamsDS->Open();
			ParamsDS->Last();
			TDateTime d2=ParamsDS->FieldByName(DateField)->AsDateTime;
			ParamsDS->Close();
			DBSQLConn->Close();
			AnsiString st1=d1.DateTimeString();
			if (!st1.AnsiCompareIC("30.12.1899")) st1=" ?";
			AnsiString st2=d2.DateTimeString();
			if (!st2.AnsiCompareIC("30.12.1899")) st2=" ?";
			StringGrid3->Cells[1][i]=st1 + " - " + st2;

			} catch (...) {
				int i=1;
			}
		}
	}
	if (StringGrid3->RowCount>0)
		SelectedRow3=0;
	else
		SelectedRow3=-1;
}       */
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::RadioButton1Click(TObject *Sender)
{
	SetMode(RadioButton1->Checked);
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::RadioButton2Click(TObject *Sender)
{
	SetMode(!RadioButton2->Checked);
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::StringGrid3DrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State)
{
	StringGrid3->Canvas->Font->Color=clBlack;
	if (ACol==1)
	{
		if (ARow==SelectedRow3)
			StringGrid3->Canvas->Brush->Color=clGreen;
		else
			StringGrid3->Canvas->Brush->Color=clMedGray;
			StringGrid3->Canvas->FillRect(Rect);
			StringGrid3->Canvas->TextOut(Rect.Left,Rect.Top,StringGrid3->Cells[ACol][ARow]);

	}
}
//---------------------------------------------------------------------------

void __fastcall TSelectTrendsForm::StringGrid3SelectCell(TObject *Sender, int ACol,
		  int ARow, bool &CanSelect)
{
	if (StringGrid3->Cells[0][ARow]!="")
	{
		SelectedRow3=ARow;
	}
}
//---------------------------------------------------------------------------

