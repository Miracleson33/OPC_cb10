//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "mnemo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
//---------------------------------------------------------------------------
#include <main.h>
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//-------------------------------------------------------
//---------------------------------------------------------------------------
//TTag *LTags[100];
//---------------------------------------------------------------------------
__fastcall TTOU::TTOU(int id, int x, int y)
{
	TypeTOU=0;
	X=0;
	Y=0;
	idTOU=id;
	UseTOU=false;
	X=x;
	X+=(int)MnemoForm->X0Mnemo;;
	Y=y+MnemoForm->Y0Mnemo;;

	Image1TOU = new TImage(NULL);
	Image2TOU = new TImage(NULL);
	LabelTOU = new TLabel(NULL);

	AnsiString st;
	st=Form1->MnemoDirectory+"_on.bmp";
	Image1TOU->Picture->LoadFromFile(st);
	Image1TOU->Width=Image1TOU->Picture->Width;
	Image1TOU->Height=Image1TOU->Picture->Height;
	st=Form1->MnemoDirectory+"_off.bmp";
	Image2TOU->Picture->LoadFromFile(st);
	Image2TOU->Width=Image2TOU->Picture->Width;
	Image2TOU->Height=Image2TOU->Picture->Height;
	Image1TOU->Left=X;
	Image1TOU->Top=Y;
	Image2TOU->Left=X;
	Image2TOU->Top=Y;

	Image1TOU->OnMouseDown=POnMouseDown;
	Image1TOU->OnMouseUp=POnMouseUp;
	Image1TOU->OnMouseMove=POnMouseMove;
	Image2TOU->OnMouseDown=POnMouseDown;
	Image2TOU->OnMouseUp=POnMouseUp;
	Image2TOU->OnMouseMove=POnMouseMove;

	LabelTOU->Font->Size=9;
	LabelTOU->Font->Height=-14;
	LabelTOU->Font->Style=TFontStyles() << fsBold;// <<fsItalic;// << fsUnderline;
	LabelTOU->Left=X;
	LabelTOU->Top=Y;
	ControlParam=-1;

	LabelTOU->Transparent=true;
	MnemoForm->MDown=false;
}
//-------------------------------------------------------
__fastcall TTOU::~TTOU(void)
{
}
//-------------------------------------------------------
void __fastcall TTOU::POnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=true;
	MnemoForm->SelectedTOU=idTOU;
	MnemoForm->RefreshTOU(idTOU);
}
//-------------------------------------------------------
void __fastcall TTOU::POnMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=false;
	MnemoForm->SelectedTOU=idTOU;
	MnemoForm->RefreshTOU(idTOU);
}
//-------------------------------------------------------
void __fastcall TTOU::POnMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
	if (MnemoForm->MDown)
	{
		int x=Image1TOU->Left+X-Image1TOU->Width/2;
		int y=Image1TOU->Top+Y-Image1TOU->Height/2;
		MnemoForm->SetPosTOU(idTOU, x, y, true);
	}
}
//---------------------------------------------------------------------------
//void TTOU::SetPosTOU(int x0, int y0, int x, int y)
//{
//	X=x;
//	Y=y;
//	Image1TOU->Left=X;//+x0;
//	Image1TOU->Top=Y;//+y0;
//	Image2TOU->Left=X;//+x0;
//	Image2TOU->Top=Y;//+y0;
//	LabelTOU->Left=X;//+x0;
//	LabelTOU->Top=Y;//+y0;
//	MnemoForm->SetPosTOU(idTOU, x, y, true);
//}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall TTag::TTag(int id, int x, int y): TLabel(Owner)
{
	OnMouseDown=POnMouseDown;
	OnMouseUp=POnMouseUp;
	OnMouseMove=POnMouseMove;
	idTag=id;
	UseTag=false;
	X=x;
	X+=(int)MnemoForm->X0Mnemo;;
	Y=y+MnemoForm->Y0Mnemo;;
	Font->Size=9;
	Font->Height=-11;
	Font->Style=TFontStyles() << fsBold;// <<fsItalic;// << fsUnderline;
	Left=X;
	Top=Y;
	Val=0;
	Transparent=true;
	MnemoForm->MDown=false;
}
//-------------------------------------------------------
__fastcall TTag::~TTag(void)
{
}
//-------------------------------------------------------
void __fastcall TTag::POnMouseDown(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=true;
	MnemoForm->SelectedTag=idTag;
	MnemoForm->RefreshTags(idTag);
}
//-------------------------------------------------------
void __fastcall TTag::POnMouseUp(TObject *Sender, TMouseButton Button, TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=false;
	MnemoForm->SelectedTag=idTag;
	MnemoForm->RefreshTags(idTag);
}
//-------------------------------------------------------
void __fastcall TTag::POnMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
	if (MnemoForm->MDown)
	{
		int x=Left+X-Width/2;
		int y=Top+Y-Height/2;
//		SetPosTag(0, 0, x, y);
		MnemoForm->SetPosTag(idTag, x, y, true);
	}
}
//---------------------------------------------------------------------------
//void TTag::SetPosTag(int x0, int y0, int x, int y)
//{
//	X=x;
//	Y=y;
//	Left=X;//+x0;
//	Top=Y;//+y0;
//	MnemoForm->SetPosTag(idTag, x, y, true);
//}

//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
class TConfigMnemo
{
	public:
	AnsiString StInfo;
	AnsiString StTag;;
	bool SostReadTagOpen;
	bool SostReadTagClose;
	bool SostReadInfo;
	int LenTag;
	int LenInfo;
};
//---------------------------------------------------------------------------
TMnemoForm *MnemoForm;
//---------------------------------------------------------------------------
__fastcall TMnemoForm::TMnemoForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void TMnemoForm::SetPosTOU(int idTOU, int x, int y, bool Manual)
{
	if ((MnemoForm->GoEdit->Checked)||(!Manual))
	{
		MnemoForm->TOU[idTOU]->X=x;
		MnemoForm->TOU[idTOU]->Y=y;
		MnemoForm->TOU[idTOU]->Image1TOU->Left=x;
		MnemoForm->TOU[idTOU]->Image1TOU->Top=y;
		MnemoForm->TOU[idTOU]->Image2TOU->Left=x;
		MnemoForm->TOU[idTOU]->Image2TOU->Top=y;
		int dy1=5;
		if (MnemoForm->TOU[idTOU]->TypeTOU==0) dy1=5;
		if (MnemoForm->TOU[idTOU]->TypeTOU==1) dy1=75;
		int dx=(MnemoForm->TOU[idTOU]->Image1TOU->Width-MnemoForm->TOU[idTOU]->LabelTOU->Width)/2;
		int dy=MnemoForm->TOU[idTOU]->Image1TOU->Height-dy1-MnemoForm->TOU[idTOU]->LabelTOU->Height;
		MnemoForm->TOU[idTOU]->LabelTOU->Left=MnemoForm->TOU[idTOU]->Image1TOU->Left+dx;
		MnemoForm->TOU[idTOU]->LabelTOU->Top=MnemoForm->TOU[idTOU]->Image1TOU->Top+dy;
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::SetPosTag(int idTag, int x, int y, bool Manual)
{
	if ((MnemoForm->GoEdit->Checked)||(!Manual))
	{
		MnemoForm->LTags[idTag]->X=x;
		MnemoForm->LTags[idTag]->Y=y;
		MnemoForm->LTags[idTag]->Left=x;//+x0;
		MnemoForm->LTags[idTag]->Top=y;//+y0;
		MnemoForm->M[MnemoForm->CurMnemo].X[idTag]=x;
		MnemoForm->M[MnemoForm->CurMnemo].Y[idTag]=y;
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::Init(AnsiString AboutMnemo)
{
		MnemoForm->MaxTOU=100;
		MnemoForm->SelectedTOU=-1;
		MnemoForm->NumTOU=0;
		for (int i = 0; i < MnemoForm->MaxTOU; i++)
		{
			MnemoForm->TOU[i] = new TTOU(i, i*5, i*4);
			MnemoForm->TOU[i]->Image1TOU->Parent=MnemoForm->MnemoBox;
			MnemoForm->TOU[i]->Image1TOU->BringToFront();
			MnemoForm->TOU[i]->Image2TOU->Parent=MnemoForm->MnemoBox;
			MnemoForm->TOU[i]->Image2TOU->BringToFront();
			MnemoForm->TOU[i]->LabelTOU->Parent=MnemoForm->MnemoBox;
			MnemoForm->TOU[i]->LabelTOU->BringToFront();
			MnemoForm->TOU[i]->UseTOU=false;
			MnemoForm->TOU[i]->Image1TOU->Visible=false;
			MnemoForm->TOU[i]->Image2TOU->Visible=false;
			MnemoForm->NumTOU++;
		}
/*		for (int i = 0; i < 9; i++)
		{
			SetPosTOU(i, i*30, i*20, false);
			MnemoForm->TOU[i]->UseTOU=true;
			int ix=MnemoForm->TOU[i]->Image1TOU->Left;
			int iy=MnemoForm->TOU[i]->Image1TOU->Top;
			ix=MnemoForm->TOU[i]->Image1TOU->Left;
		}*/

		MnemoForm->MaxTags=100;
		MnemoForm->LoadMnemoConfig();

		CurMnemo=0;
		for (int i = 0; i < NumMnemo; i++)
		{
			if (!M[i].About.AnsiCompare(AboutMnemo))
			{
				CurMnemo=i;
			}
		}

		MnemoForm->AddTagMode=false;
		MnemoForm->EditMode=false;
		MnemoForm->SetMnemo(EditMode);

		MnemoForm->SelectedTag=-1;
		MnemoForm->InitTags();

		MnemoForm->SelectedRowServer=-1;
		MnemoForm->SelectedRowTag=-1;
		MnemoForm->ListServers();

		ListAddedTags();

		MnemoForm->EditMode=false;
		MnemoForm->MDown=false;
		MnemoForm->RefreshTOU(MnemoForm->SelectedTOU);
		MnemoForm->RefreshTags(MnemoForm->SelectedTag);
		MnemoForm->TagsLoop->Enabled=true;
}
//---------------------------------------------------------------------------
void TMnemoForm::InitTags()
{
	MnemoForm->NumTags=0;
	for (int i = 0; i < MnemoForm->MaxTags; i++)
	{
		MnemoForm->LTags[i] = new TTag(i, i*10, i*7);
		MnemoForm->LTags[i]->Parent=MnemoForm->MnemoBox;
		if ((MnemoForm->CurMnemo>=0)&&(i<MnemoForm->M[MnemoForm->CurMnemo].NumTags))
		{
			MnemoForm->LTags[i]->UseTag=true;
			MnemoForm->LTags[i]->NTable=MnemoForm->M[MnemoForm->CurMnemo].NTable[i];
			MnemoForm->LTags[i]->NameTag=MnemoForm->M[MnemoForm->CurMnemo].NameTag[i];
			MnemoForm->LTags[i]->AboutTag=MnemoForm->M[MnemoForm->CurMnemo].AboutTag[i];
			MnemoForm->LTags[i]->Caption=MnemoForm->LTags[i]->NameTag;
			MnemoForm->SetPosTag
			(
				i,
//				MnemoForm->X0Mnemo,
//				MnemoForm->Y0Mnemo,
				MnemoForm->M[MnemoForm->CurMnemo].X[i],
				MnemoForm->M[MnemoForm->CurMnemo].Y[i],
				false
			);
			for (int j=0;j<Form1->ListTrends[Form1->ValidOPCServers[MnemoForm->LTags[i]->NTable].idTrend].NumVar;j++)
			{
				if (!Form1->TTrends[MnemoForm->LTags[i]->NTable].NameField[j].AnsiCompare(MnemoForm->LTags[i]->NameTag))
				{
					MnemoForm->LTags[i]->NParam=j;
                }
			}
			MnemoForm->NumTags++;
		}
		else
		{
			MnemoForm->LTags[i]->UseTag=false;
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall TMnemoForm::ButtonEditClick(TObject *Sender)
{
	MnemoForm->EditMode^=true;
	MnemoForm->SetMnemo(MnemoForm->EditMode);
	MnemoForm->Position=poDesktopCenter;
//	if (MnemoForm->SelectedTag>=0) MnemoForm->LTags[MnemoForm->SelectedTag]->SetFocus();
}
//---------------------------------------------------------------------------
void __fastcall TMnemoForm::ButtonCloseClick(TObject *Sender)
{
	MnemoForm->SaveMnemoConfig();
	MnemoForm->Close();
}
//---------------------------------------------------------------------------
void __fastcall TMnemoForm::ServersGridDrawCell(TObject *Sender, int ACol, int ARow,
		  TRect &Rect, TGridDrawState State)
{
	ServersGrid->Canvas->Font->Color=clBlack;
	if (ARow==SelectedRowServer)
		ServersGrid->Canvas->Brush->Color=clGreen;
	else
		ServersGrid->Canvas->Brush->Color=clMedGray;
		ServersGrid->Canvas->FillRect(Rect);
		ServersGrid->Canvas->TextOut(Rect.Left,Rect.Top,ServersGrid->Cells[ACol][ARow]);
}
//---------------------------------------------------------------------------
void __fastcall TMnemoForm::ServersGridSelectCell(TObject *Sender, int ACol, int ARow,
		  bool &CanSelect)
{
	SelectedRowServer=ARow;
	int id=ServersGrid->Cells[0][SelectedRowServer].ToInt();
	id=ServersGrid->Cells[0][SelectedRowServer].ToInt();
	ListTags(id);
	MnemoForm->SelectedRowTag=-1;
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//void __fastcall TMnemoForm::SetMnemo(bool EditMode)
void TMnemoForm::SetMnemo(bool EditMode)
{
	MnemoBox->TabStop=false;


	EditBox->TabStop=false;
	ServersGrid->TabStop=false;
	TagsGrid->TabStop=false;
	AddedTagsGrid->TabStop=false;
	AddTagButton->TabStop=false;
	DeleteTagButton->TabStop=false;

	ControlBox->TabStop=false;
	XTagEdit->TabStop=false;
	YTagEdit->TabStop=false;
	ButtonEdit->TabStop=false;

	ServersGrid->Left=5;
	ServersGrid->Top=13;
	ServersGrid->Width=200;
	ServersGrid->Height=175;
	ServersGrid->ColWidths[0]=0;
	ServersGrid->ColWidths[1]=0;
	ServersGrid->ColWidths[2]=ServersGrid->Width-8;
	AddedTagsGrid->Left=ServersGrid->Left+ServersGrid->Width+2;
	AddedTagsGrid->Top=ServersGrid->Top;
	AddedTagsGrid->Width=200;
	AddedTagsGrid->ColCount=4;
	AddedTagsGrid->ColWidths[0]=20;
	AddedTagsGrid->ColWidths[1]=20;
	AddedTagsGrid->ColWidths[2]=20;
	AddedTagsGrid->ColWidths[3]=AddedTagsGrid->Width-83;
	EditBox->Left=0;
	EditBox->Top=0;
	EditBox->Width=ServersGrid->Width+AddedTagsGrid->Width+10+2;

	int X0;
	if (EditMode)
	{
		X0=EditBox->Width;
		ServersGrid->Visible=true;
		EditBox->Visible=true;
	}
	else
	{
		X0=0;
		ServersGrid->Visible=false;
		EditBox->Visible=false;
	}
	AnsiString FullMnemoFile=Form1->MnemoDirectory+M[CurMnemo].Img;
	MnemoField->Picture->LoadFromFile(FullMnemoFile);
	MnemoField->Top=13;
	MnemoField->Left=5;
	MnemoField->Height=MnemoField->Picture->Height;
	MnemoField->Width=MnemoField->Picture->Width;
	MnemoBox->Top=0;
	MnemoBox->Left=X0+0;
	MnemoBox->Height=MnemoField->Height+18;
	MnemoBox->Width=MnemoField->Width+10;
	MnemoBox->Caption="����";//M[CurMnemo].About;

	ControlBox->Top=MnemoBox->Top+MnemoBox->Height-2;
	ControlBox->Left=MnemoBox->Left;
	ControlBox->Height=ButtonClose->Height+15;
	ControlBox->Width=MnemoBox->Width;

	ButtonClose->Top=ControlBox->Top+10;
	ButtonClose->Left=ControlBox->Left+ControlBox->Width-ButtonClose->Width-5;
	MnemoForm->Height=MnemoBox->Height+ControlBox->Height+25;
	MnemoForm->Width=X0+MnemoBox->Width+6;
	MnemoForm->Caption=M[CurMnemo].About;

	EditBox->Height=MnemoForm->Height-27;

	AddTagButton->Left=TagsGrid->Left+(TagsGrid->Width-AddTagButton->Width)/2;
	AddTagButton->Top=EditBox->Top+EditBox->Height-5-AddTagButton->Height;
	DeleteTagButton->Left=AddedTagsGrid->Left+(AddedTagsGrid->Width-DeleteTagButton->Width)/2;;
	DeleteTagButton->Top=AddTagButton->Top;

	TagsGrid->Left=ServersGrid->Left;
	TagsGrid->Top=ServersGrid->Top+ServersGrid->Height+2;
	TagsGrid->Width=ServersGrid->Width;
	TagsGrid->Height=AddTagButton->Top - TagsGrid->Top - 5;
	TagsGrid->ColWidths[0]=0;
	TagsGrid->ColWidths[1]=0;
	TagsGrid->ColWidths[2]=TagsGrid->Width-8;
	AddedTagsGrid->Height=DeleteTagButton->Top - AddedTagsGrid->Top - 5;

	if (EditMode)
	{
		X0=EditBox->Width;
		ServersGrid->Visible=true;
		EditBox->Visible=true;
		AddTagButton->Visible=true;
		DeleteTagButton->Visible=true;
		ButtonEdit->Caption="�������� ����� >>";
	}
	else
	{
		X0=0;
		ServersGrid->Visible=false;
		EditBox->Visible=false;
		AddTagButton->Visible=false;
		DeleteTagButton->Visible=false;
		ButtonEdit->Caption="<< �������� �����";
	}
		ButtonEdit->Left=ControlBox->Left+5;
		ButtonEdit->Top=ControlBox->Top+10;
		GoEdit->Left=ControlBox->Left+ButtonEdit->Width+10;
		GoEdit->Top=ButtonEdit->Top+5;
//		GoEdit->Left=ButtonEdit->Width+5;
//		GoEdit->Top=ButtonEdit->Width+10;
		X0Mnemo=MnemoField->Left;
		Y0Mnemo=MnemoField->Top;

		LabelNameTagLabel->Left=GoEdit->Width+160;
		LabelNameTagLabel->Top=15;
		NameTagLabel->Left=GoEdit->Width+190;
		NameTagLabel->Top=15;

		LabelAboutTagLabel->Left=GoEdit->Width+290;
		LabelAboutTagLabel->Top=15;
		AboutTagLabel->Left=GoEdit->Width+350;
		AboutTagLabel->Top=15;

		LabelXTagLabel->Left=GoEdit->Width+450;
		LabelXTagLabel->Top=15;
		XTagEdit->Left=GoEdit->Width+470;
		XTagEdit->Top=10;

		LabelYTagLabel->Left=GoEdit->Width+610;
		LabelYTagLabel->Top=15;
		YTagEdit->Left=GoEdit->Width+630;
		YTagEdit->Top=10;

		TimeLabel->Left=GoEdit->Width+450;
		TimeLabel->Top=15;
		DateTimePicker1->Left=TimeLabel->Left+TimeLabel->Width+5;
		DateTimePicker1->Top=10;
		DateTimePicker2->Left=DateTimePicker1->Left+DateTimePicker1->Width+5;
		DateTimePicker2->Top=10;
		NowTimeBox->Left=DateTimePicker2->Left+DateTimePicker2->Width+5;
		NowTimeBox->Top=15;

/*		LabelNameTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+30;
		LabelNameTagLabel->Top=15;
		NameTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+60;
		NameTagLabel->Top=15;
		LabelAboutTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+170;
		LabelAboutTagLabel->Top=15;
		AboutTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+230;
		AboutTagLabel->Top=15;
		LabelXTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+350;
		LabelXTagLabel->Top=15;
		XTagEdit->Left=ButtonEdit->Left+ButtonEdit->Width+370;
		XTagEdit->Top=10;
		LabelYTagLabel->Left=ButtonEdit->Left+ButtonEdit->Width+500;
		LabelYTagLabel->Top=15;
		YTagEdit->Left=ButtonEdit->Left+ButtonEdit->Width+520;
		YTagEdit->Top=10;*/
//		ButtonClose->sel
}

//---------------------------------------------------------------------------
void TMnemoForm::LoadMnemoConfig()
{
	int iFileHandle=0;
	int iFileLength;
	int iBytesRead;
	char *pszBuffer;
	AnsiString NameFile="mnemo.ini";
	AnsiString FullNameFile=Form1->MnemoDirectory+NameFile;
	if (FileExists(FullNameFile))
	{
		iFileHandle = FileOpen(FullNameFile,fmOpenRead);
	}
	else
	{
		Application->MessageBox(L"���� ������������ ����� �� ������", L"���������", MB_OK);
	}
	if (iFileHandle)
	{
        iFileLength = FileSeek(iFileHandle,0,2);
		FileSeek(iFileHandle,0,0);
		pszBuffer = new char[iFileLength+1];
		iBytesRead = FileRead(iFileHandle, pszBuffer, iFileLength);
		FileClose(iFileHandle);
	}
	char to;
	to='<';
	char tc;
	tc='>';
	char tcc;
	tcc='/';
	char ch1, ch2;

	TConfigMnemo CM[10];
	int MaxLevel=10;
	int Level=0;
	for (int i = 0; i < MaxLevel; i++)
	{
		CM[i].StInfo="";
		CM[i].StTag="";
		CM[i].SostReadTagOpen=false;
		CM[i].SostReadTagClose=false;
		CM[i].SostReadInfo=false;
		CM[i].LenTag=0;
		CM[i].LenInfo=0;
	}

	MaxMnemo=10;
	NumMnemo=0;
	CurMnemo=-1;
	VerConfigMnemo="0.0";
	for (int i = 0; i < MaxMnemo; i++)
	{
		M[i].Name="";
		M[i].About="";
		M[i].Img="";
		M[i].NumTags=0;
		for (int j = 0; j < MaxTags; j++)
		{
			M[i].NTable[j]=0;
			M[i].NameTag[j]="";
			M[i].AboutTag[j]="";
			M[i].X[j]=0;
			M[i].Y[j]=0;
		}
	}
	NumTOU=0;

	for (int c=0; c < iBytesRead; c++)
	{
		ch1=pszBuffer[c];
		if ((c+1)<iBytesRead) ch2=pszBuffer[c+1];
		for (int i=0;i<Level;i++)
		{
				CM[i].StInfo.operator +=(ch1);
				CM[i].LenInfo++;
		}
		if (CM[Level].SostReadTagOpen||CM[Level].SostReadTagClose)
		{
			if ((ch1!=to)&&(ch1!=tc)&&(ch1!=tcc))
			{
				CM[Level].StTag.operator +=(ch1);
				CM[Level].LenTag++;
			}
		}
		if (CM[Level].SostReadInfo)
		{
			if ((ch1!=to)&&(ch1!=tc)&&(ch1!=tcc))
			{
				CM[Level].StInfo.operator +=(ch1);
				CM[Level].LenInfo++;
			}
		}
		if (ch1==to)
		{
			if (ch2==tcc)
			{
				c++;
				CM[Level].SostReadTagClose=true;
				CM[Level].SostReadInfo=false;
				String St1=CM[Level].StInfo.c_str();
				String St2=CM[Level].StTag.c_str();
//				Application->MessageBox(St1.c_str(), St2.c_str(), MB_OK);
				CM[Level].LenTag=0;
				CM[Level].StTag="";
			}
			else
			{
				if (CM[Level].SostReadInfo) Level++;
				if (Level>=MaxLevel) Level=MaxLevel-1;
				CM[Level].SostReadTagOpen=true;
				CM[Level].SostReadInfo=false;
				CM[Level].LenTag=0;
				CM[Level].StTag="";
			}
		}
		if (ch1==tc)
		{
			if (CM[Level].SostReadTagClose)
			{
				CM[Level].SostReadTagClose=false;
				String St=CM[Level].StTag.c_str();
//				Application->MessageBox(St.c_str(), L"����������� ���", MB_OK);
				if (!CM[Level].StTag.AnsiCompare("ver"))
				{
					VerConfigMnemo=CM[Level].StInfo;
				}
				if (NumMnemo>0)
				{
					if (!CM[Level].StTag.AnsiCompare("name"))
					{
						M[NumMnemo-1].Name=CM[Level].StInfo;
					}
					if (!CM[Level].StTag.AnsiCompare("about"))
					{
						M[NumMnemo-1].About=CM[Level].StInfo;
					}
					if (!CM[Level].StTag.AnsiCompare("img"))
					{
						M[NumMnemo-1].Img=CM[Level].StInfo;
					}
					if (NumTOU>0)
					{
						if (!CM[Level].StTag.AnsiCompare("idtou"))
						{
							TOU[NumTOU-1]->idTOU=AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("typetou"))
						{
							TOU[NumTOU-1]->TypeTOU=AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("ntou"))
						{
							TOU[NumTOU-1]->NameTOU=CM[Level].StInfo;
						}
						if (!CM[Level].StTag.AnsiCompare("atou"))
						{
							TOU[NumTOU-1]->AboutTOU=CM[Level].StInfo;
						}
						if (!CM[Level].StTag.AnsiCompare("imgtou"))
						{
							TOU[NumTOU-1]->ImageFileTOU=CM[Level].StInfo;
						}
						if (!CM[Level].StTag.AnsiCompare("xtou"))
						{
							TOU[NumTOU-1]->X=AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("ytou"))
						{
							TOU[NumTOU-1]->Y=AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("ptou"))
						{
							TOU[NumTOU-1]->ControlParam=AnsiString(CM[Level].StInfo).ToInt();
						}
					}
					if (M[NumMnemo-1].NumTags>0)
					{
						if (!CM[Level].StTag.AnsiCompare("ttag"))
						{
							M[NumMnemo-1].NTable[M[NumMnemo-1].NumTags-1] =AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("ntag"))
						{
							M[NumMnemo-1].NameTag[M[NumMnemo-1].NumTags-1] =CM[Level].StInfo;
						}
						if (!CM[Level].StTag.AnsiCompare("atag"))
						{
							M[NumMnemo-1].AboutTag[M[NumMnemo-1].NumTags-1] =CM[Level].StInfo;
						}
						if (!CM[Level].StTag.AnsiCompare("xtag"))
						{
							M[NumMnemo-1].X[M[NumMnemo-1].NumTags-1] =AnsiString(CM[Level].StInfo).ToInt();
						}
						if (!CM[Level].StTag.AnsiCompare("ytag"))
						{
							M[NumMnemo-1].Y[M[NumMnemo-1].NumTags-1] =AnsiString(CM[Level].StInfo).ToInt();
						}
					}
				}
				Level--;
				if (Level<0) Level=0;
			}
			if (CM[Level].SostReadTagOpen)
			{
				CM[Level].SostReadTagOpen=false;
				CM[Level].SostReadInfo=true;
				CM[Level].LenInfo=0;
				CM[Level].StInfo="";
				String St=CM[Level].StTag.c_str();
//				Application->MessageBox(St.c_str(), L"����������� ���", MB_OK);
				if (!CM[Level].StTag.AnsiCompare("mnemo"))
				{
					NumMnemo++;
					CurMnemo=NumMnemo-1;
				}
				if (!CM[Level].StTag.AnsiCompare("tou"))
				{
					TOU[NumTOU]->UseTOU=true;
					NumTOU++;
				}
				if (!CM[Level].StTag.AnsiCompare("tag"))
				{
					M[NumMnemo-1].UseTag[M[NumMnemo-1].NumTags]=true;
					M[NumMnemo-1].NumTags++;
				}
			}
		}
	}
	for (int i=0;i<NumTOU;i++)
	{
		TOU[i]->LabelTOU->Caption=TOU[i]->NameTOU;
		AnsiString st;
		st=Form1->MnemoDirectory+TOU[i]->ImageFileTOU+"_on.bmp";
		TOU[i]->Image1TOU->Picture->LoadFromFile(st);
		TOU[i]->Image1TOU->Width=TOU[i]->Image1TOU->Picture->Width;
		TOU[i]->Image1TOU->Height=TOU[i]->Image1TOU->Picture->Height;
		st=Form1->MnemoDirectory+TOU[i]->ImageFileTOU+"_off.bmp";
		TOU[i]->Image2TOU->Picture->LoadFromFile(st);
		TOU[i]->Image2TOU->Width=TOU[i]->Image2TOU->Picture->Width;
		TOU[i]->Image2TOU->Height=TOU[i]->Image2TOU->Picture->Height;
		TOU[i]->UseTOU=true;
		TOU[i]->Image1TOU->Visible=true;
		TOU[i]->Image2TOU->Visible=true;
		SetPosTOU(i, TOU[i]->X, TOU[i]->Y, false);
	}

}
//---------------------------------------------------------------------------
void TMnemoForm::SaveMnemoConfig()
{
	int iFileHandle=0;
	AnsiString NameFile="mnemo.ini";
	AnsiString FullNameFile=Form1->MnemoDirectory+NameFile;
	AnsiString st;
	st="";
	char c0=9;
	char c1=32;
	char c2=13;
	char c3=10;
	if (FileExists(FullNameFile))
	{
		DeleteFile(FullNameFile);
		iFileHandle = FileCreate(FullNameFile);
//		iFileHandle = FileOpen(FullNameFile,fmOpenWrite);
	}
	else
	{
		iFileHandle = FileCreate(FullNameFile);
	}
	if (iFileHandle)
	{
		st.operator +=("<ver>");
		st.operator +=(MnemoForm->VerConfigMnemo);
		st.operator +=("</ver>");
		st.operator +=(c2);
		st.operator +=(c3);
		for (int i = 0; i < MnemoForm->NumMnemo; i++)
		{
			st.operator +=("<mnemo>");
			st.operator +=(c2);
			st.operator +=(c3);

			st.operator +=("<name>");
			st.operator +=(M[i].Name);
			st.operator +=("</name>");
			st.operator +=(c2);
			st.operator +=(c3);

			st.operator +=("<about>");
			st.operator +=(M[i].About);
			st.operator +=("</about>");
			st.operator +=(c2);
			st.operator +=(c3);

			st.operator +=("<img>");
			st.operator +=(M[i].Img);
			st.operator +=("</img>");
			st.operator +=(c2);
			st.operator +=(c3);

			for (int j = 0; j < MaxTOU; j++)
			{
				if (TOU[j]->UseTOU)
				{
					st.operator +=("<tou>");
					st.operator +=(c2);
					st.operator +=(c3);

					st.operator +=("<idtou>");
					st.operator +=(AnsiString(TOU[j]->idTOU));
					st.operator +=("</idtou>");
					st.operator +=(c2);
					st.operator +=(c3);
					st.operator +=("<typetou>");
					st.operator +=(AnsiString(TOU[j]->TypeTOU));
					st.operator +=("</typetou>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].NTable[M[NumMnemo-1].Numtous-1]
					st.operator +=("<ntou>");
					st.operator +=(TOU[j]->NameTOU);
					st.operator +=("</ntou>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].Nametou[M[NumMnemo-1].Numtous-1]
					st.operator +=("<atou>");
					st.operator +=(TOU[j]->AboutTOU);
					st.operator +=("</atou>");
					st.operator +=(c2);
					st.operator +=(c3);
					st.operator +=("<imgtou>");
					st.operator +=(TOU[j]->ImageFileTOU);
					st.operator +=("</imgtou>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].Abouttou[M[NumMnemo-1].Numtous-1]
					st.operator +=("<xtou>");
					st.operator +=(AnsiString(TOU[j]->X));
					st.operator +=("</xtou>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].X[M[NumMnemo-1].Numtous-1]
					st.operator +=("<ytou>");
					st.operator +=(AnsiString(TOU[j]->Y));
					st.operator +=("</ytou>");
					st.operator +=(c2);
					st.operator +=(c3);
					st.operator +=("<ptou>");
					st.operator +=(AnsiString(TOU[j]->ControlParam));
					st.operator +=("</ptou>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].Y[M[NumMnemo-1].Numtous-1]

					st.operator +=("</tou>");
					st.operator +=(c2);
					st.operator +=(c3);
				}
			}

			for (int j = 0; j < MaxTags; j++)
			{
				if (MnemoForm->M[i].UseTag[j])
				{
					st.operator +=("<tag>");
					st.operator +=(c2);
					st.operator +=(c3);

					st.operator +=("<ttag>");
					st.operator +=(AnsiString(M[i].NTable[j]));
					st.operator +=("</ttag>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].NTable[M[NumMnemo-1].NumTags-1]
					st.operator +=("<ntag>");
					st.operator +=(M[i].NameTag[j]);
					st.operator +=("</ntag>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].NameTag[M[NumMnemo-1].NumTags-1]
					st.operator +=("<atag>");
					st.operator +=(M[i].AboutTag[j]);
					st.operator +=("</atag>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].AboutTag[M[NumMnemo-1].NumTags-1]
					st.operator +=("<xtag>");
					st.operator +=(AnsiString(M[i].X[j]));
					st.operator +=("</xtag>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].X[M[NumMnemo-1].NumTags-1]
					st.operator +=("<ytag>");
					st.operator +=(AnsiString(M[i].Y[j]));
					st.operator +=("</ytag>");
					st.operator +=(c2);
					st.operator +=(c3);
//M[i].Y[M[NumMnemo-1].NumTags-1]

					st.operator +=("</tag>");
					st.operator +=(c2);
					st.operator +=(c3);
				}
			}
			st.operator +=("</mnemo>");
		}
		FileSeek(iFileHandle, 0, 0);
		FileWrite(iFileHandle, st.c_str(), st.Length());

		FileClose(iFileHandle);
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::ListServers()
{
	ServersGrid->RowCount=Form1->NumConnectedOPCServers;
	for (int j=0;j<Form1->NumConnectedOPCServers;j++)
	{
		int id=Form1->OPCServers[j].idTrend;
		ServersGrid->Cells[0][j]=id;
		ServersGrid->Cells[2][j]=Form1->ListTrends[id].TrendName;
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::ListTags(int id)
{
	TagsGrid->RowCount=Form1->ListTrends[id].NumVar;
	for (int j=0;j<Form1->ListTrends[id].NumVar;j++)
	{
		TagsGrid->Cells[0][j]=j;
		TagsGrid->Cells[2][j]=Form1->TTrends[id].AboutField[j];
		TagsGrid->Cells[1][j]=Form1->TTrends[id].NameField[j];
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::RefreshTOU(int idTOU)
{
	for (int i=0;i<MnemoForm->NumTOU;i++)
	{
		double Val=530;
		if (MnemoForm->TOU[i]->TypeTOU==0) Val=530;
		if (MnemoForm->TOU[i]->TypeTOU==1) Val=10;
		if (MnemoForm->TOU[i]->ControlParam>=0)
		{
			if (MnemoForm->LTags[MnemoForm->TOU[i]->ControlParam]->Val>=Val)
			{
				MnemoForm->TOU[i]->Image2TOU->Hide();
				MnemoForm->TOU[i]->Image1TOU->Show();
			}
			else
			{
				MnemoForm->TOU[i]->Image1TOU->Hide();
				MnemoForm->TOU[i]->Image2TOU->Show();
			}
		}
	}
	if (NowTimeBox->Checked)
	{
		DateTimePicker1->DateTime=Now();
		DateTimePicker2->DateTime=Now();
	}
}
//---------------------------------------------------------------------------
void TMnemoForm::RefreshTags(int idTag)
{
	static int NLoop=0;
	NLoop++;
//	MnemoForm->Label1->Caption=AnsiString(NLoop);
//	MnemoForm->SelectedTag=idTag;
	MnemoForm->SelectedTag=SelectedTag;
	AnsiString st;//=AnsiString(MnemoForm->SelectedTag);

	int ik;
	for (ik=0;ik<MnemoForm->NumTags;ik++)
	{
		if (MnemoForm->LTags[ik]->UseTag)
		{
			MnemoForm->LTags[ik]->Visible=true;
			if (MnemoForm->EditMode)
			{
				MnemoForm->LTags[ik]->Caption=MnemoForm->LTags[ik]->NameTag;
			}
			else
			{
				if (Form1->OPCServers[MnemoForm->LTags[ik]->NTable].ServerConnect)
				{
					double Val=Form1->OPCServers[MnemoForm->LTags[ik]->NTable].FloatValField[MnemoForm->LTags[ik]->NParam];
					MnemoForm->LTags[ik]->Val=Val;
					st=AnsiString(Val).SetLength(5);
				}
				else
				{
					MnemoForm->LTags[ik]->Val=-1;
					st="�/�";
				}
				MnemoForm->LTags[ik]->Caption=st;
			}
			if (ik==MnemoForm->SelectedTag)
			{
				MnemoForm->LTags[ik]->Font->Color=clWhite;
				MnemoForm->LTags[ik]->Color=clBlack;
				MnemoForm->LTags[ik]->Transparent=false;
			}
			else
			{
				MnemoForm->LTags[ik]->Font->Color=clBlack;
				MnemoForm->LTags[ik]->Transparent=true;
				int x=MnemoForm->LTags[ik]->X;
				int y=MnemoForm->LTags[ik]->Y;
				MnemoForm->LTags[ik]->Color=MnemoForm->MnemoField->Canvas->Pixels[x][y];
			}
		}
		else
		{
			MnemoForm->LTags[ik]->Visible=false;
		}
	}
	if (MnemoForm->SelectedTag>=0)
	{
		MnemoForm->XTagEdit->Text=MnemoForm->LTags[MnemoForm->SelectedTag]->Left;//MnemoForm->M[MnemoForm->CurMnemo].X[MnemoForm->SelectedTag];
		MnemoForm->YTagEdit->Text=MnemoForm->LTags[MnemoForm->SelectedTag]->Top;//MnemoForm->M[MnemoForm->CurMnemo].Y[MnemoForm->SelectedTag];
		MnemoForm->NameTagLabel->Caption=MnemoForm->LTags[MnemoForm->SelectedTag]->NameTag;
		MnemoForm->AboutTagLabel->Caption=MnemoForm->LTags[MnemoForm->SelectedTag]->AboutTag;
		MnemoForm->AddedTagsGrid->Refresh();
	}
	else
	{
		MnemoForm->XTagEdit->Text="";
		MnemoForm->YTagEdit->Text="";
		MnemoForm->NameTagLabel->Caption="�� ������";
		MnemoForm->AboutTagLabel->Caption="�� ������";
	}
	if (MnemoForm->AddTagMode)
	{
		MnemoForm->AddTagButton->Caption="�������� ����������";
	}
	else
	{
		MnemoForm->AddTagButton->Caption="�������� �� ���� >>";
	}
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridDrawCell(TObject *Sender, int ACol, int ARow,
		  TRect &Rect, TGridDrawState State)
{
	TagsGrid->Canvas->Font->Color=clBlack;
	if (ARow==SelectedRowTag)
		TagsGrid->Canvas->Brush->Color=clGreen;
	else
		TagsGrid->Canvas->Brush->Color=clMedGray;
		TagsGrid->Canvas->FillRect(Rect);
		TagsGrid->Canvas->TextOut(Rect.Left,Rect.Top,TagsGrid->Cells[ACol][ARow]);
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridSelectCell(TObject *Sender, int ACol, int ARow,
          bool &CanSelect)
{
	SelectedRowTag=ARow;
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridDragDrop(TObject *Sender, TObject *Source, int X,
		  int Y)
{
	int DX=X;
	int DY=Y;
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridDragOver(TObject *Sender, TObject *Source, int X,
          int Y, TDragState State, bool &Accept)
{
	int DX=X;
	int DY=Y;
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridEndDock(TObject *Sender, TObject *Target, int X,
          int Y)
{
	int DX=X;
	int DY=Y;

}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::TagsGridEndDrag(TObject *Sender, TObject *Target, int X,
          int Y)
{
	int DX=X;
	int DY=Y;

}
//---------------------------------------------------------------------------


void __fastcall TMnemoForm::MnemoFieldMouseDown(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=true;
	if (!MnemoForm->AddTagMode)
	{
		MnemoForm->SelectedTag=-1;
	}
	else
	{
		if ((MnemoForm->SelectedRowTag>=0)&&(MnemoForm->SelectedRowServer>=0))
		{
			for (int i=0;i<MnemoForm->MaxTags;i++)
			{
				if (!MnemoForm->LTags[i]->UseTag)
				{
					int x=X+MnemoForm->X0Mnemo;
					int y=Y+MnemoForm->X0Mnemo;
					MnemoForm->LTags[i]->UseTag=true;
					MnemoForm->LTags[i]->NTable=ServersGrid->Cells[0][MnemoForm->SelectedRowServer].ToInt();
					MnemoForm->LTags[i]->NParam=TagsGrid->Cells[0][MnemoForm->SelectedRowTag].ToInt();
					MnemoForm->LTags[i]->NameTag=TagsGrid->Cells[1][MnemoForm->SelectedRowTag];
					MnemoForm->LTags[i]->AboutTag=TagsGrid->Cells[2][MnemoForm->SelectedRowTag];
					MnemoForm->SetPosTag
					(
						i,
						x,
						y,
						false
					);
					MnemoForm->NumTags++;
//					for (int j=0;j<MnemoForm->MaxTags;j++)
//					{
//						if (!MnemoForm->M[MnemoForm->CurMnemo].UseTag[j])
//						{
							MnemoForm->M[MnemoForm->CurMnemo].UseTag[i]=true;
							MnemoForm->M[MnemoForm->CurMnemo].NTable[i]=MnemoForm->LTags[i]->NTable;
							MnemoForm->M[MnemoForm->CurMnemo].NameTag[i]=MnemoForm->LTags[i]->NameTag;
							MnemoForm->M[MnemoForm->CurMnemo].AboutTag[i]=MnemoForm->LTags[i]->AboutTag;
							MnemoForm->M[MnemoForm->CurMnemo].X[i]=MnemoForm->LTags[i]->X;
							MnemoForm->M[MnemoForm->CurMnemo].Y[i]=MnemoForm->LTags[i]->Y;
							MnemoForm->M[MnemoForm->CurMnemo].NumTags++;
//							break;
//						}
//					}
					break;
				}
			}
		}
		MnemoForm->AddTagMode=false;
	}
	MnemoForm->ListAddedTags();
	RefreshTags(MnemoForm->SelectedTag);
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::FormClose(TObject *Sender, TCloseAction &Action)
{
	MnemoForm->TagsLoop->Enabled=false;
	for (int i = 0;i <NumTags; i++)
	{
		delete LTags[i];
	}
}
//-------------------------------------------------------


void __fastcall TMnemoForm::TagsLoopTimer(TObject *Sender)
{
	MnemoForm->RefreshTOU(MnemoForm->SelectedTOU);
	MnemoForm->RefreshTags(MnemoForm->SelectedTag);
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::MnemoFieldMouseUp(TObject *Sender, TMouseButton Button,
          TShiftState Shift, int X, int Y)
{
	MnemoForm->MDown=false;
}
//---------------------------------------------------------------------------






void __fastcall TMnemoForm::MnemoFieldMouseMove(TObject *Sender, TShiftState Shift, int X, int Y)
{
	if (MnemoForm->MDown)
	{
		int x=MnemoForm->LTags[SelectedTag]->Left+X-MnemoForm->LTags[SelectedTag]->Width/2;
		int y=MnemoForm->LTags[SelectedTag]->Top+Y-MnemoForm->LTags[SelectedTag]->Height/2;
		if (SelectedTag>=0)
		{
			MnemoForm->SetPosTag
			(
				MnemoForm->SelectedTag,
				x,
				y,
				false
			);
		}
	}
}
//---------------------------------------------------------------------------



void __fastcall TMnemoForm::AddTagButtonClick(TObject *Sender)
{
	if (!MnemoForm->AddTagMode)
	{
		if (MnemoForm->SelectedRowTag>=0)
		{
			MnemoForm->AddTagMode=true;
		}
		else
		{
			Application->MessageBox(L"�� ������ �������� ��� ��� ���������� �� ����������.", L"��������", MB_OK);
		}
	}
	else
	{
		MnemoForm->AddTagMode=false;
	}
	MnemoForm->RefreshTags(MnemoForm->SelectedTag);
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::DeleteTagButtonClick(TObject *Sender)
{
	if (MnemoForm->SelectedTag>=0)
	{
		MnemoForm->LTags[MnemoForm->SelectedTag]->UseTag=false;
		MnemoForm->ListAddedTags();
	}
	else
	{
		Application->MessageBox(L"�� ������ �������� ��� ��� �������� � ����������.", L"��������", MB_OK);
	}
}
//---------------------------------------------------------------------------

void TMnemoForm::ListAddedTags()
{
	MnemoForm->AddedTagsGrid->RowCount=0;
	for (int i=0;i<MnemoForm->NumTags;i++)
	{
		if ((MnemoForm->LTags[i]->UseTag))
		{
			MnemoForm->AddedTagsGrid->Cells[0][MnemoForm->AddedTagsGrid->RowCount-1]=MnemoForm->LTags[i]->idTag;
			MnemoForm->AddedTagsGrid->Cells[1][MnemoForm->AddedTagsGrid->RowCount-1]=MnemoForm->LTags[i]->NTable;
			MnemoForm->AddedTagsGrid->Cells[2][MnemoForm->AddedTagsGrid->RowCount-1]=MnemoForm->LTags[i]->NParam;
			MnemoForm->AddedTagsGrid->Cells[3][MnemoForm->AddedTagsGrid->RowCount-1]=MnemoForm->LTags[i]->NameTag;
			MnemoForm->AddedTagsGrid->RowCount++;
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::FormKeyPress(TObject *Sender, wchar_t &Key)
{
	if (SelectedTag>=0)
	{
		if (Key==(wchar_t)"w")
		{
			int x=MnemoForm->LTags[SelectedTag]->Left;
			int y=MnemoForm->LTags[SelectedTag]->Top-1;
			MnemoForm->SetPosTag
			(
				MnemoForm->SelectedTag,
				x,
				y,
				false
			);
		}
	}
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift)
{
	if (SelectedTag>=0)
	{
		int dx=0;
		int dy=0;
		if (Key==37)
		{
			dx=-1;
			dy=0;
		}
		if (Key==38)
		{
			dx=0;
			dy=-1;
		}
		if (Key==39)
		{
			dx=1;
			dy=0;
		}
		if (Key==40)
		{
			dx=0;
			dy=1;
		}
		int x=MnemoForm->LTags[SelectedTag]->X+dx;
		int y=MnemoForm->LTags[SelectedTag]->Y+dy;
		MnemoForm->SetPosTag
		(
			MnemoForm->SelectedTag,
			x,
			y,
			false
		);
	}
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::GoEditClick(TObject *Sender)
{
	ButtonEdit->Enabled^=true;
	TimeLabel->Visible^=true;
	DateTimePicker1->Visible^=true;
	DateTimePicker2->Visible^=true;
	NowTimeBox->Visible^=true;
	LabelXTagLabel->Visible^=true;
	XTagEdit->Visible^=true;
	LabelYTagLabel->Visible^=true;
	YTagEdit->Visible^=true;
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::AddedTagsGridDrawCell(TObject *Sender, int ACol, int ARow,
          TRect &Rect, TGridDrawState State)
{
	AddedTagsGrid->Canvas->Font->Color=clBlack;
	if (MnemoForm->AddedTagsGrid->Cells[0][ARow]==MnemoForm->SelectedTag)
		AddedTagsGrid->Canvas->Brush->Color=clGreen;
	else
		AddedTagsGrid->Canvas->Brush->Color=clMedGray;
		AddedTagsGrid->Canvas->FillRect(Rect);
		AddedTagsGrid->Canvas->TextOut(Rect.Left,Rect.Top,AddedTagsGrid->Cells[ACol][ARow]);
}
//---------------------------------------------------------------------------

void __fastcall TMnemoForm::AddedTagsGridSelectCell(TObject *Sender, int ACol, int ARow,
          bool &CanSelect)
{
	if (MnemoForm->AddedTagsGrid->Cells[0][ARow]!="")
	{
		MnemoForm->SelectedTag=MnemoForm->AddedTagsGrid->Cells[0][ARow].ToInt();
		MnemoForm->RefreshTags(MnemoForm->SelectedTag);
		MnemoForm->AddedTagsGrid->Refresh();
	}
}
//---------------------------------------------------------------------------

