//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------
USEFORM("main.cpp", Form1);
USEFORM("findserv.cpp", Form2);
USEFORM("selecttrends.cpp", SelectTrendsForm);
USEFORM("trends.cpp", TrendForm);
USEFORM("selectcolor.cpp", SelectColorForm);
USEFORM("mnemo.cpp", MnemoForm);
USEFORM("startmessenger.cpp", startform);
//---------------------------------------------------------------------------
WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TForm1), &Form1);
		Application->CreateForm(__classid(TForm2), &Form2);
		Application->CreateForm(__classid(TSelectColorForm), &SelectColorForm);
		Application->CreateForm(__classid(TSelectTrendsForm), &SelectTrendsForm);
		Application->CreateForm(__classid(TTrendForm), &TrendForm);
		Application->CreateForm(__classid(TMnemoForm), &MnemoForm);
		Application->CreateForm(__classid(Tstartform), &startform);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
