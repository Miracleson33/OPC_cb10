//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "TestThread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(&UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TTestThread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------
#include <main.h>
//---------------------------------------------------------------------------

__fastcall TTestThread::TTestThread(bool CreateSuspended)
	: TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void __fastcall TTestThread::Execute()
{
//	FreeOnTerminate=true;
	NameThreadForDebugging("TestThread");
	//---- Place thread code here ----
	NumIter=0;
	Form1->CloseTestThread=false;
	while ((!Form1->CloseTestThread))
	{
		NumIter++;
		Synchronize(Show);
	}
}
//---------------------------------------------------------------------------

void __fastcall TTestThread::Show()
{
	wchar_t s[8];

	AnsiString sca = "����������: ";
	_itow(NumIter, s, 10);
	sca.operator +=(s);
	Form1->Label2->Caption=sca;
}
//---------------------------------------------------------------------------