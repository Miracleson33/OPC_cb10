//---------------------------------------------------------------------------

#ifndef TrendReadThreadH
#define TrendReadThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
#include <opcda.h>
//#include "opcda_i.c"

class TTrendReadThread : public TThread
{
private:
protected:
	void __fastcall Execute();
	void __fastcall Read();
	void __fastcall Show();
	void __fastcall ShowInfo();
	void __fastcall ReOpenDB();
	void __fastcall ReconnectDBSQL();
public:
	int iidTrend;
	int ServerRead;
	int ItemRead;
	int nTrendFile;
	int ShowRow;
	AnsiString ShowVal;
	int ShowNum;
	int ShowOK;
	int ShowErr;
	HRESULT *phResultRead;
	OPCITEMSTATE* pItemStateRead;
	HRESULT hrRead;
	__fastcall TTrendReadThread(bool CreateSuspended);
	__fastcall ~TTrendReadThread(void);
};
//---------------------------------------------------------------------------
#endif
