//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "selectcolor.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TSelectColorForm *SelectColorForm;
//---------------------------------------------------------------------------
__fastcall TSelectColorForm::TSelectColorForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSelectColorForm::StringGrid1SelectCell(TObject *Sender,
      int ACol, int ARow, bool &CanSelect)
{
	SelectedRow=ARow;
}
//---------------------------------------------------------------------------

void __fastcall TSelectColorForm::StringGrid1DrawCell(TObject *Sender,
      int ACol, int ARow, TRect &Rect, TGridDrawState State)
{
	if (ACol==1)
	{
			StringGrid1->Canvas->Brush->Color=Form1->Colors[ARow];
			StringGrid1->Canvas->FillRect(Rect);
            StringGrid1->Canvas->TextOut(Rect.Left,Rect.Top,StringGrid1->Cells[ACol][ARow]);
	}
}
//---------------------------------------------------------------------------




void __fastcall TSelectColorForm::FormActivate(TObject *Sender)
{
	StringGrid1->ColCount=2;
	StringGrid1->RowCount=24;
	StringGrid1->ColWidths[0]=0;
	StringGrid1->ColWidths[1]=StringGrid1->Height-5;
	Label3->Caption=Form1->TTrends[Form1->SelectedTrend].NameField[Form1->SelectedParam];
	SelectedRow=Form1->ListTrends[Form1->SelectedTrend].Color[Form1->SelectedParam];
	Edit1->Text=Form1->ListTrends[Form1->SelectedTrend].MinY[Form1->SelectedParam];
	Edit2->Text=Form1->ListTrends[Form1->SelectedTrend].MaxY[Form1->SelectedParam];
	Edit3->Text=Form1->ListTrends[Form1->SelectedTrend].Y[Form1->SelectedParam];
	Edit4->Text=Form1->ListTrends[Form1->SelectedTrend].ScaleY[Form1->SelectedParam];
	CheckBox1->Checked=Form1->ListTrends[Form1->SelectedTrend].Visible[Form1->SelectedParam];
}
//---------------------------------------------------------------------------

void __fastcall TSelectColorForm::FormClose(TObject *Sender, TCloseAction &Action)
{
	SelectTrendsForm->StringGrid2->Repaint();

}
//---------------------------------------------------------------------------

void __fastcall TSelectColorForm::Button1Click(TObject *Sender)
{
	Form1->ListTrends[Form1->SelectedTrend].Color[Form1->SelectedParam]=SelectedRow;
	int i1=_wtoi(Edit1->Text.c_str());
	int i2=_wtoi(Edit2->Text.c_str());
	int i3=_wtoi(Edit3->Text.c_str());
	int i4=_wtoi(Edit4->Text.c_str());
	Form1->ListTrends[Form1->SelectedTrend].MinY[Form1->SelectedParam]=i1;
	Form1->ListTrends[Form1->SelectedTrend].MaxY[Form1->SelectedParam]=i2;
	Form1->ListTrends[Form1->SelectedTrend].Y[Form1->SelectedParam]=i3;
	Form1->ListTrends[Form1->SelectedTrend].ScaleY[Form1->SelectedParam]=i4;
	SelectTrendsForm->StringGrid2->Cells[3][Form1->SelectedParam]=i1;
	SelectTrendsForm->StringGrid2->Cells[4][Form1->SelectedParam]=i2;
//	TrendForm->StringGrid1->Cells[3][Form1->SelectedParam]=i1;
//	TrendForm->StringGrid1->Cells[4][Form1->SelectedParam]=i2;
	SelectColorForm->Close();
}
//---------------------------------------------------------------------------

void __fastcall TSelectColorForm::Button2Click(TObject *Sender)
{
	SelectColorForm->Close();
}
//---------------------------------------------------------------------------

void __fastcall TSelectColorForm::CheckBox1Click(TObject *Sender)
{
	Form1->ListTrends[Form1->SelectedTrend].Visible[Form1->SelectedParam]=CheckBox1->Checked;

}
//---------------------------------------------------------------------------

