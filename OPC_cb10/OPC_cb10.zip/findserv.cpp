//---------------------------------------------------------------------------

#include <vcl.h>
#include <main.h>
#pragma hdrstop

#include "findserv.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
    : TForm(Owner)
{
//    ThrFindServ = new TFindServersTread(true);
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormActivate(TObject *Sender)
{
    AbortFindServers=false;
    GetServers();
}
//---------------------------------------------------------------------------

void __fastcall TForm2::GetServers()
{
    Form1->StringGrid1->RowCount=0;
    Form1->StringGrid1->Rows[0]->Clear();
    ComputerName = Form1->ComboBox1->Text;
//    FindServersStat=false;
    TFindServersThread *ThrFindServ = new TFindServersThread(true);
    ThrFindServ->Resume();
    //return FindServersStat;
}
//---------------------------------------------------------------------------

int __fastcall TForm2::FindServers(int Version)
{
    USES_CONVERSION;
	Form1->User1 = (wchar_t)(Form1->Edit1->Text.c_str());
	Form1->Password1 = (wchar_t)(Form1->MaskEdit1->Text.c_str());
	Form1->Domain1 = "";//(wchar_t)(Form1->ComboBox2->Text.c_str());
	Form1->ServerName = (wchar_t)(Form1->ComboBox1->Text.c_str());
//    Form1->User1 = WideString(Form1->Edit1->Text.c_str());
//    Form1->Password1 = WideString(Form1->MaskEdit1->Text.c_str());
//    Form1->Domain1 = WideString(Form1->ComboBox2->Text.c_str());
//    Form1->ServerName = WideString(Form1->ComboBox1->Text.c_str());

    COAUTHIDENTITY caId;
    caId.User = (unsigned short*) Form1->User1.m_str;
    caId.Password = (unsigned short*) Form1->Password1.m_str;
    caId.Domain = (unsigned short*) Form1->Domain1.m_str;
    caId.Flags = SEC_WINNT_AUTH_IDENTITY_UNICODE;
    caId.UserLength = Form1->User1.Length() ;
    caId.PasswordLength = Form1->Password1.Length();
    caId.DomainLength = Form1->Domain1.Length();

    COAUTHINFO caInfo;
    caInfo.dwAuthnLevel = RPC_C_AUTHN_LEVEL_CONNECT;
    caInfo.dwAuthnSvc = RPC_C_AUTHN_WINNT;
    caInfo.dwAuthzSvc = RPC_C_AUTHZ_NONE;
    caInfo.dwCapabilities = EOAC_NONE;
    caInfo.dwImpersonationLevel = RPC_C_IMP_LEVEL_IMPERSONATE;
    caInfo.pAuthIdentityData = &caId;
    caInfo.pwszServerPrincName = NULL;

    COSERVERINFO csInfo;
    csInfo.pwszName = Form1->ServerName;
    csInfo.pAuthInfo = &caInfo;
    csInfo.dwReserved1 = 0;
    csInfo.dwReserved2 = 0;

    MULTI_QI mQI;
    mQI.pIID=&IID_IOPCServerList;
    mQI.pItf=NULL;
    mQI.hr=S_OK;

    int FindServ=0;
    HRESULT hResult, hr2;

    hResult = CoCreateInstanceEx(CLSID_OpcServerList, NULL,
                                    CLSCTX_REMOTE_SERVER,
                                &csInfo, 1, &mQI);

	ICatInformation *pCat;
    if (FAILED(hResult))
    {
        Form1->ServerConnect=false;
        if (hResult==E_INVALIDARG) return -2;
        if (hResult==REGDB_E_CLASSNOTREG) return -3;
        if (hResult==CLASS_E_NOAGGREGATION) return -4;
        if (hResult==CO_S_NOTALLINTERFACES) return -5;
        if (hResult==E_NOINTERFACE) return -6;
        return -7;
    }
    else
    {
        if (mQI.hr == S_OK)
        {
            USES_CONVERSION;
            IOPCServerList *OPCServerList;
            OPCServerList = (IOPCServerList*)mQI.pItf;

            IEnumCLSID * pEnumGUID;
//            for (int i=1
	    	CLSID catid = IID_CATID_OPCDAServer10;//IID_CATID_XMLDAServer10;//CATID_OPCDAServer10;//IID_CATID_OPCDAServer10;
//            if (Version==2) catid = IID_CATID_OPCDAServer20;//CATID_OPCDAServer20;
//            if (Version==3) catid = IID_CATID_OPCDAServer30;


            hr2 = OPCServerList->EnumClassesOfCategories(1, &catid,
		                                        		1, &catid, &pEnumGUID);
    		if (SUCCEEDED(hr2))
    		{
        		ULONG c;
        		GUID clsid;
                Form1->StringGrid1->RowCount=0;
                Form1->StringGrid1->Cells[1][0]="";
                int n=0;
        		while (SUCCEEDED(hr2 = pEnumGUID->Next(1, &clsid, &c)))
                {
                    LPOLESTR pszProgID;
                    LPOLESTR pszUserType;
                    hr2 = OPCServerList->GetClassDetails(clsid,
                                                    &pszProgID, &pszUserType);
                    if (FAILED(hr2))
                    {
                        break;
                    }
                    Form1->StringGrid1->RowCount=n+1;

                    LPOLESTR clsidstr = NULL;
                    StringFromCLSID(clsid, &clsidstr);

                    Form1->StringGrid1->Cells[0][n]= clsidstr;
                    Form1->StringGrid1->Cells[1][n]=pszProgID;
                    FindServ=1;
                    n++;
                    CoTaskMemFree(pszProgID);
                    CoTaskMemFree(pszUserType);
                }
        		if(OPCServerList) OPCServerList->Release();
			}
        }
	}
    return FindServ;
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender)
{
    AbortFindServers=true;
}
//---------------------------------------------------------------------------







