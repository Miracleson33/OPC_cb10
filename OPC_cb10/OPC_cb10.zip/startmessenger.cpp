//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "startmessenger.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
Tstartform *startform;
//---------------------------------------------------------------------------
__fastcall Tstartform::Tstartform(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
