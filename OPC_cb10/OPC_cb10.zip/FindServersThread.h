//---------------------------------------------------------------------------

#ifndef FindServersThreadH
#define FindServersThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
#include <main.h>
#include <findserv.h>
//---------------------------------------------------------------------------
class TFindServersThread : public TThread
{
private:
protected:
    void __fastcall Execute();
public:
	__fastcall TFindServersThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif

