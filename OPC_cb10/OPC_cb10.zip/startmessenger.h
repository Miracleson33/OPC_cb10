//---------------------------------------------------------------------------

#ifndef startmessengerH
#define startmessengerH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class Tstartform : public TForm
{
__published:	// IDE-managed Components
	TListBox *StartMessBox;
private:	// User declarations
public:		// User declarations
	__fastcall Tstartform(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tstartform *startform;
//---------------------------------------------------------------------------
#endif
