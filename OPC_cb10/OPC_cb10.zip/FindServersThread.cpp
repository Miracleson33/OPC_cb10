//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "FindServersThread.h"
#pragma package(smart_init)
//---------------------------------------------------------------------------

//   Important: Methods and properties of objects in VCL can only be
//   used in a method called using Synchronize, for example:
//
//      Synchronize(UpdateCaption);
//
//   where UpdateCaption could look like:
//
//      void __fastcall TFindServersTread::UpdateCaption()
//      {
//        Form1->Caption = "Updated in a thread";
//      }
//---------------------------------------------------------------------------

__fastcall TFindServersThread::TFindServersThread(bool CreateSuspended)
    : TThread(CreateSuspended)
{
}
//---------------------------------------------------------------------------
void __fastcall TFindServersThread::Execute()
{
    FreeOnTerminate = true;
    bool FindServersStat=false;

    TRegistry *Registry = new TRegistry(KEY_READ);
    Registry->RootKey = HKEY_CLASSES_ROOT;
    AnsiString ProgID;
    AnsiString ValName;
    CLSID clsid;
    TStringList *KeyNames = new TStringList();
    AnsiString Description;
    AnsiString Vendor;
    int NumKeys=0;
	if (!Registry->RegistryConnect(Form2->ComputerName))
    {
        Application->MessageBox(L"�� ������ ���������", L"���������", MB_OK);
        FindServersStat=false;
    }
    else
    {
        if (!Registry->OpenKeyReadOnly(""))
        {
            FindServersStat=false;
        }
        else
        {
            Registry->GetKeyNames(KeyNames);
            NumKeys = KeyNames->Count;
            Registry->CloseKey();
            Form2->ProgressBar1->Max=NumKeys;
            Form2->ProgressBar1->Min=0;
            int n=0;
            for (int i=0; i<NumKeys;i++)
            {
                if (Form2->AbortFindServers)
                {
                    break;
                }
                Form2->ProgressBar1->Position=i;
                ProgID = KeyNames->Strings[i];
                if (Registry->OpenKeyReadOnly(ProgID))
                {
                    if (Registry->OpenKeyReadOnly("OPC"))
                    {
                        Registry->CloseKey();
                        if (Registry->OpenKeyReadOnly(ProgID))
                        {
                            if (Registry->OpenKeyReadOnly("CLSID"))
                            {
                                FindServersStat=true;
                                ValName=Registry->ReadString("");
                                Form1->StringGrid1->RowCount=n+1;
                                Form1->StringGrid1->Cells[0][n]=ValName;
                                Form1->StringGrid1->Cells[1][n]=ProgID;
                                Form1->StringGrid1->Cells[2][n]=Form2->ComputerName;
								n++;
                            }
                        }
                    }
                    Registry->CloseKey();
                }
            }
            Form2->ProgressBar1->Position=0;
            delete Registry;
        }
    }

    if (FindServersStat)
    {
        Form1->StringGrid1->Enabled=true;
    }
    else
    {
        Form1->StringGrid1->RowCount=1;
        Form1->StringGrid1->Cells[1][0]="OPC ������� �� �������";
        Form1->Button2->Enabled=false;
    }
    Form2->Close();
}
//---------------------------------------------------------------------------

