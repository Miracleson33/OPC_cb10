//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAEMessForm *AEMessForm;
//---------------------------------------------------------------------------
__fastcall TAEMessForm::TAEMessForm(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
