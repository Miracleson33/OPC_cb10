//---------------------------------------------------------------------------

#ifndef LoadTrendsThreadH
#define LoadTrendsThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
#include <main.h>
#include <findserv.h>
#include <Classes.hpp>

class TLoadTrendsThread : public TThread
{
private:
protected:
    void __fastcall Execute();
public:
    __fastcall TLoadTrendsThread(bool CreateSuspended);
};
//---------------------------------------------------------------------------
#endif

