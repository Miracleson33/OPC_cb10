//---------------------------------------------------------------------------

#ifndef selecttrendsH
#define selecttrendsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
#include <main.h>
#include <Grids.hpp>
#include <Dialogs.hpp>
#include <FileCtrl.hpp>
#include <ADODB.hpp>
#include <DB.hpp>
//---------------------------------------------------------------------------

class TSelectTrendsForm : public TForm
{
__published:	// IDE-managed Components
    TGroupBox *GroupBox1;
    TLabel *Label1;
    TStringGrid *StringGrid1;
    TLabel *Label2;
    TStringGrid *StringGrid2;
    TButton *Button1;
    TButton *Button2;
	TFileListBox *FileListBox1;
	TLabel *Label3;
	TRadioButton *RadioButton1;
	TRadioButton *RadioButton2;
	TStringGrid *StringGrid3;
	TADOConnection *ADOConnection1;
    void __fastcall Button1Click(TObject *Sender);
    void __fastcall Button2Click(TObject *Sender);
	void __fastcall FormActivate(TObject *Sender);
    void __fastcall StringGrid1DrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
    void __fastcall StringGrid1SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
    void __fastcall StringGrid2DrawCell(TObject *Sender, int ACol,
          int ARow, TRect &Rect, TGridDrawState State);
    void __fastcall StringGrid2SelectCell(TObject *Sender, int ACol,
          int ARow, bool &CanSelect);
	void __fastcall FileListBox1Click(TObject *Sender);
	void __fastcall RadioButton1Click(TObject *Sender);
	void __fastcall RadioButton2Click(TObject *Sender);
	void __fastcall StringGrid3DrawCell(TObject *Sender, int ACol, int ARow, TRect &Rect,
          TGridDrawState State);
	void __fastcall StringGrid3SelectCell(TObject *Sender, int ACol, int ARow, bool &CanSelect);

private:	// User declarations
public:		// User declarations
    __fastcall TSelectTrendsForm(TComponent* Owner);

	void __fastcall SetMode(bool RM);
	int SelectedRow;
	int SelectedRow3;
		TADOQuery* ParamsDS;
		TADOQuery* TablesDS[100];
		TADOConnection* DBSQLConn;
		bool RemouteMode;
};
//---------------------------------------------------------------------------
extern PACKAGE TSelectTrendsForm *SelectTrendsForm;
//---------------------------------------------------------------------------
#endif
