//---------------------------------------------------------------------------

#ifndef TestThreadH
#define TestThreadH
//---------------------------------------------------------------------------
#include <Classes.hpp>
//---------------------------------------------------------------------------
class TTestThread : public TThread
{
protected:
	void __fastcall Execute();
	void __fastcall Show();
public:
	__fastcall TTestThread(bool CreateSuspended);
	int NumIter;
};
//---------------------------------------------------------------------------
#endif


